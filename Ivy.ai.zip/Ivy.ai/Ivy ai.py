# -*- coding: utf-8 -*-
# Pharma Desk — One-AI-Call/Action (FULL, LLM-Enhanced One-Box)
# Drug & Company analytics + Market Shares (Total & ATC-L2/L3) with Pies (Units & Value)
# + Company Peers (>=10% overlap) + Top-N Reports (Companies/Drugs/Brands by Units/Value)
# + LLM Router with FA-first company detection, FA→EN drug fallback, and AI CodeGen executor (result-only; no code leak)
# English UI; Persian inputs allowed.

import os, io, sys, json, time, hashlib, threading, traceback, warnings, re
from collections import OrderedDict
from pathlib import Path
warnings.filterwarnings("ignore")

from langchain_openai import ChatOpenAI
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser

import pandas as pd
import numpy as np

# Matplotlib
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
plt.rcParams.update({
    "figure.dpi": 100,
    "figure.constrained_layout.use": True,
    "font.family": ["DejaVu Sans", "Arial", "sans-serif"],
    "axes.unicode_minus": False,
})
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

# Tk
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext, filedialog

# Optional libs
try:
    from deep_translator import GoogleTranslator
    HAS_TRANSLATOR = True
except Exception:
    HAS_TRANSLATOR = False

try:
    import arabic_reshaper
    from bidi.algorithm import get_display as _bidi
    HAS_BIDI = True
except Exception:
    HAS_BIDI = False

# --------------- App/Config Paths

def app_dir() -> Path:
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS)
    try:
        return Path(__file__).resolve().parent
    except NameError:
        return Path.cwd()

APP_DIR = app_dir()
ASSETS_DIR = APP_DIR / "assets"
CONFIG_PATH = (APP_DIR / "pharmadesk_config.json") if getattr(sys, "frozen", False) else (Path.home() / ".pharmadesk_config.json")

def pick_existing(*candidates: str) -> str:
    for p in candidates:
        if p and os.path.isfile(p):
            return p
    return candidates[0] if candidates else ""

# --- Excel paths (adjust as needed)
ABS_SALES = r"C:\Users\Annuminas\Downloads\Dataset 1399-1403.xlsx"
ABS_ATC   = r"D:\ARAS\آمارنامه\ATC.xlsx"
REL_SALES = str((ASSETS_DIR / "Dataset 1399-1403.xlsx").resolve())
REL_ATC   = str((ASSETS_DIR / "ATC.xlsx").resolve())
SALES_XLSX = pick_existing(ABS_SALES, REL_SALES)
ATC_XLSX   = pick_existing(ABS_ATC, REL_ATC)

# --------------- Config (API keys and knobs)
DEFAULT_CONFIG = {
    "OPENAI_API_KEY": " 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",
    "OPENAI_MODEL": "gpt-5",
    "AI_CALLS_ENABLED": True,
    "AI_CACHE_TTL_SEC": 600,
    "AI_MIN_INTERVAL_SEC": 5,
    "AI_MAX_PER_MINUTE": 6,
    "GOOGLE_CSE_API_KEY": "AIzaSyCdQORXQYS_hNLLykNUExScVKBZwl3z3Us",
    "GOOGLE_CSE_CX": "d5086ce7fd7e64c8f"
}

def load_config():
    try:
        if CONFIG_PATH.exists():
            return {**DEFAULT_CONFIG, **json.loads(CONFIG_PATH.read_text(encoding="utf-8"))}
    except Exception:
        pass
    return DEFAULT_CONFIG.copy()

def save_config(cfg: dict):
    CONFIG_PATH.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")

CONFIG = load_config()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", CONFIG.get("OPENAI_API_KEY","")).strip()
OPENAI_MODEL   = CONFIG.get("OPENAI_MODEL","gpt-5")
AI_CALLS_ENABLED = bool(CONFIG.get("AI_CALLS_ENABLED", True))
AI_CACHE_TTL_SEC = int(CONFIG.get("AI_CACHE_TTL_SEC", 600))
AI_MIN_INTERVAL  = int(CONFIG.get("AI_MIN_INTERVAL_SEC", 5))
AI_MAX_PER_MIN   = int(CONFIG.get("AI_MAX_PER_MINUTE", 6))
GOOGLE_CSE_API_KEY = CONFIG.get("GOOGLE_CSE_API_KEY","")
GOOGLE_CSE_CX      = CONFIG.get("GOOGLE_CSE_CX","")

# --------------- OpenAI client
try:
    from openai import OpenAI
    openai_client = OpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None
except Exception:
    openai_client = None

# --------------- Helpers

def normalize_fa(text: str) -> str:
    if pd.isna(text): return ""
    s = str(text)
    s = (s.replace("\u064A", "\u06CC").replace("\u0643", "\u06A9").replace("\u200c","").replace("‌",""))
    s = " ".join(s.split())
    return s.strip()

def is_arabic_text(s: str) -> bool:
    if not isinstance(s, str): return False
    return any('\u0600' <= ch <= '\u06FF' for ch in s)

def fa_display(s: str) -> str:
    if not s: return s
    if HAS_BIDI and is_arabic_text(s):
        try: return _bidi(arabic_reshaper.reshape(s))
        except Exception: return s
    return s

def fmt_int(x):
    try: return f"{int(round(float(x))):,}"
    except Exception: return "0"

def fmt_pct4(x):
    try: return f"{float(x):.4f}%"
    except Exception: return "0.0000%"

def cagr(start, end, n):
    if start <= 0 or n < 2: return 0.0
    return (end / start) ** (1 / (n - 1)) - 1

def yoy(series: pd.Series):
    return series.pct_change().fillna(0)

def _nice_scale(max_val: float):
    max_val = float(max_val or 0)
    if max_val >= 1e12: return 1e12, "trillion"
    if max_val >= 1e9:  return 1e9,  "billion"
    if max_val >= 1e6:  return 1e6,  "million"
    if max_val >= 1e3:  return 1e3,  "thousand"
    return 1, ""

# ===== Digits: Persian ↔ English
PERSIAN_DIGITS = "۰۱۲۳۴۵۶۷۸۹"
EN_DIGITS      = "0123456789"
P2E_MAP = str.maketrans(PERSIAN_DIGITS, EN_DIGITS)

def to_en_digits(s: str) -> str:
    if not isinstance(s, str): s = str(s)
    return s.translate(P2E_MAP)

def extract_year_from_text(text: str, default=None):
    t = to_en_digits(text)
    m = re.findall(r"(13\d{2}|14\d{2})", t)
    if m:
        try: return int(m[0])
        except: pass
    return default

def extract_n_from_text(text: str, default=10):
    t = to_en_digits(text)
    m = re.findall(r"\b(\d{1,3})\b", t)
    if m:
        try: return int(m[0])
        except: pass
    return default

# ===== RTL-Fixed plotting functions =====
def smart_plot(title, x, y_series, y_label):
    ser = pd.Series(y_series)
    scale, suffix = _nice_scale(ser.max())
    fig, ax = plt.subplots(figsize=(7.6, 3.6))
    y = ser/scale
    ax.plot(ser.index if isinstance(ser.index, pd.Index) else x, y, marker='o')
    ax.set_title(fa_display(title))
    ax.set_xlabel(fa_display("Year"))
    ax.set_ylabel(fa_display(f"{y_label}" + (f" ({suffix})" if suffix else "")))
    ax.grid(True); ax.ticklabel_format(style="plain", axis="y")
    return fig
def plot_dual_series(title, x1, y1, x2, y2, label1, label2, y_label):
    # یک نمودار Overlay برای Head-to-Head
    s1 = pd.Series(y1).astype(float)
    s2 = pd.Series(y2).astype(float)
    # هم‌ترازسازی ایندکس‌ها
    idx = sorted(set(list(s1.index) + list(s2.index)))
    s1 = s1.reindex(idx).fillna(0)
    s2 = s2.reindex(idx).fillna(0)
    scale, suffix = _nice_scale(max(float(s1.max() or 0), float(s2.max() or 0)))
    fig, ax = plt.subplots(figsize=(7.6, 3.6))
    ax.plot(idx, s1/scale, marker='o', label=fa_display(label1))
    ax.plot(idx, s2/scale, marker='o', linestyle='--', label=fa_display(label2))
    ax.set_title(fa_display(title))
    ax.set_xlabel(fa_display("Year"))
    ax.set_ylabel(fa_display(f"{y_label}" + (f" ({suffix})" if suffix else "")))
    ax.grid(True); ax.legend(loc="best")
    ax.ticklabel_format(style="plain", axis="y")
    return fig

def _fmt_kv_table(rows):
    # رندر جدول ساده‌ی کلید-مقدار برای مقایسه
    # rows: list of (label, v1, v2, suffix)
    head = "Metric | A | B\n---|---|---"
    lines = [head]
    for lab, v1, v2, suf in rows:
        a = f"{v1}{suf}" if suf else f"{v1}"
        b = f"{v2}{suf}" if suf else f"{v2}"
        lines.append(f"{fa_display(lab)} | {a} | {b}")
    return "\n".join(lines)
def _subset_for_drug(DF: pd.DataFrame, query: str) -> pd.DataFrame:
    """Robust drug matcher: tries FA and EN, ING1-3 and Generic Name."""
    q_raw = str(query or "").strip()
    if not q_raw:
        return DF.iloc[0:0].copy()

    # نرمال‌سازی و ترجمه
    q_fa = normalize_fa(q_raw).lower()
    q_en = normalize_fa(translate_if_needed_drug(q_raw)).lower() if 'translate_if_needed_drug' in globals() else q_fa
    cands = list(dict.fromkeys([q_fa, q_en]))

    cols_ing = [c for c in ["ING1_norm","ING2_norm","ING3_norm"] if c in DF.columns]
    col_gen  = "Generic Name_norm" if "Generic Name_norm" in DF.columns else None

    hit = DF.iloc[0:0].copy()
    for q in cands:
        if q and cols_ing:
            m = DF[DF.apply(lambda r: any(q in str(r[c]) for c in cols_ing), axis=1)]
            if not m.empty:
                hit = pd.concat([hit, m], ignore_index=False)
        if q and col_gen:
            m = DF[DF[col_gen].str.contains(q, na=False)]
            if not m.empty:
                hit = pd.concat([hit, m], ignore_index=False)

    return hit.drop_duplicates()

def pie_chart(title: str, labels, values, top_k=10):
    vals = pd.Series(values, index=pd.Index([str(x) for x in labels], name="label")).astype(float)
    vals = vals.sort_values(ascending=False)
    if vals.sum() <= 0 or vals.empty:
        fig, ax = plt.subplots(figsize=(6.8, 4.2))
        ax.pie([1], labels=[fa_display("No data")], autopct=None)
        ax.set_title(fa_display(title))
        return fig
    top = vals.head(top_k)
    labels_rtled = [fa_display(s) for s in top.index.tolist()]
    fig, ax = plt.subplots(figsize=(6.8, 4.2))
    ax.pie(top.values, labels=labels_rtled, autopct=lambda p: f"{p:.1f}%")
    ax.set_title(fa_display(title))
    return fig

def pie_chart_two(title: str, label_a: str, val_a: float, label_b: str, val_b: float):
    total = float(val_a) + float(val_b)
    if total <= 0:
        fig, ax = plt.subplots(figsize=(6.2, 3.8))
        ax.pie([1], labels=[fa_display("No data")])
        ax.set_title(fa_display(title))
        return fig
    fig, ax = plt.subplots(figsize=(6.2, 3.8))
    ax.pie([max(val_a,0), max(val_b,0)],
           labels=[fa_display(label_a), fa_display(label_b)],
           autopct=lambda p: f"{p:.1f}%")
    ax.set_title(fa_display(title))
    return fig

def bar_chart_top(title: str, labels, values):
    s = pd.Series(values, index=[str(x) for x in labels], dtype=float).sort_values(ascending=True)
    fig, ax = plt.subplots(figsize=(7.6, 3.6))
    ax.barh([fa_display(k) for k in s.index.tolist()], s.values)
    ax.set_title(fa_display(title))
    ax.grid(True, axis='x')
    return fig

# --------------- Robust column mapping
def normkey(s: str) -> str:
    return normalize_fa(s).lower().replace(" ","")

def find_col(df_cols, candidates, must_contain=None):
    norm_map = {col: normkey(col) for col in df_cols}
    cand_norm = [normkey(c) for c in candidates]
    for col, ncol in norm_map.items():
        if ncol in cand_norm: return col
    if must_contain:
        mc = [normkey(x) for x in must_contain]
        for col, ncol in norm_map.items():
            if all(x in ncol for x in mc): return col
    for col, ncol in norm_map.items():
        for c in cand_norm:
            if c and c in ncol: return col
    return None

def map_columns(df):
    cols = list(df.columns)
    return {
        "Year": find_col(cols, ["Year","سال","سال شمسی","سال1399-1403"]),
        "Units": find_col(cols, ["Units","Unit Sales","فروش عددی","تعداد فروش","فروشعددی"], must_contain=["فروش","عد"]),
        "Value": find_col(cols, ["Value","Value Sales","Consumer Value","Consumer Price","فروش ریالی مصرف کننده","ارزش فروش","فروشریالیمصرفکننده"], must_contain=["فروش","ریال"]),
        "ING1": find_col(cols, ["ING1","Active Ingredient 1","ماده موثره - 1","ماده۱","ماده 1","ingredient1"]),
        "ING2": find_col(cols, ["ING2","Active Ingredient 2","ماده موثره - 2","ماده۲","ماده 2","ingredient2"]),
        "ING3": find_col(cols, ["ING3","Active Ingredient 3","ماده موثره - 3","ماده۳","ingredient3"]),
        "ATC": find_col(cols, ["ATC","ATC Code","کد ATC","کدATC"]),
        "Licensee": find_col(cols, ["Licensee","Marketing Authorization Holder","صاحب پروانه","دارنده پروانه","مالک پروانه"]),
        "Generic Name": find_col(cols, ["Generic Name","نام ژنریک","نام ژنريک","ژنریک"]),
        "Brand Name": find_col(cols, ["Brand Name","Brand","نام تجاری","نام‌تجاری","برند"]),
        "Dosage Form": find_col(cols, ["Dosage Form","Preliminary Dosage Form","فرم دارویی","شکل دارویی","فرمدارویی"])
    }

# --------------- Data load
DF, ATC = None, None

def load_data_from_paths(sales_path, atc_path):
    if not os.path.isfile(sales_path): raise FileNotFoundError(f"Sales XLSX not found: {sales_path}")
    if not os.path.isfile(atc_path):   raise FileNotFoundError(f"ATC XLSX not found: {atc_path}")

    df_raw = pd.read_excel(sales_path)
    df_raw.columns = [normalize_fa(c) for c in df_raw.columns]
    colmap = map_columns(df_raw)
    required = ["Year","Units","ING1","ATC","Licensee","Generic Name"]
    missing = [r for r in required if not colmap.get(r)]
    if missing:
        raise ValueError("Missing required columns in Sales file: " + ", ".join(missing) +
                         "\nDetected: " + ", ".join(df_raw.columns))

    df = pd.DataFrame()
    df["Year"] = pd.to_numeric(df_raw[colmap["Year"]], errors="coerce").fillna(0).astype(int)
    df["Units"] = pd.to_numeric(df_raw[colmap["Units"]], errors="coerce").fillna(0)
    df["Value"] = pd.to_numeric(df_raw.get(colmap.get("Value"), 0.0), errors="coerce").fillna(0) if colmap.get("Value") else 0.0
    df["ING1"] = df_raw[colmap["ING1"]].astype(str).fillna("")
    df["ING2"] = df_raw[colmap["ING2"]].astype(str).fillna("") if colmap.get("ING2") else ""
    df["ING3"] = df_raw[colmap["ING3"]].astype(str).fillna("") if colmap.get("ING3") else ""
    df["ATC"]  = df_raw[colmap["ATC"]].astype(str)
    df["Licensee"] = df_raw[colmap["Licensee"]].astype(str)
    df["Generic Name"] = df_raw[colmap["Generic Name"]].astype(str)
    df["Dosage Form"]  = df_raw[colmap["Dosage Form"]].astype(str) if colmap.get("Dosage Form") else ""
    if colmap.get("Brand Name"):
        df["Brand Name"] = df_raw[colmap["Brand Name"]].astype(str)
    else:
        df["Brand Name"] = ""

    # normalized helper columns
    for col in ["Licensee","Generic Name","Brand Name","ING1","ING2","ING3","Dosage Form"]:
        if col in df.columns:
            df[col+"_norm"] = df[col].astype(str).apply(lambda s: normalize_fa(s).lower())

    atc = pd.read_excel(atc_path)
    atc.columns = atc.columns.map(normalize_fa)
    return df, atc

def get_data():
    global DF, ATC
    if DF is None or ATC is None:
        DF, ATC = load_data_from_paths(SALES_XLSX, ATC_XLSX)
    return DF, ATC

# --------------- Rate limit + Cache for AI
class _RateLimiter:
    def __init__(self, min_interval_sec=5, max_per_minute=6):
        self.min_interval = float(min_interval_sec)
        self.max_per_min = int(max_per_minute)
        self.lock = threading.Lock()
        self.calls = []
        self.last_ts = 0.0
    def allow(self) -> bool:
        now = time.time()
        with self.lock:
            if now - self.last_ts < self.min_interval:
                return False
            self.calls = [t for t in self.calls if now - t < 60.0]
            if len(self.calls) >= self.max_per_min:
                return False
            self.calls.append(now)
            self.last_ts = now
            return True

class _AICache:
    def __init__(self, ttl_sec=600, capacity=256):
        self.ttl = int(ttl_sec)
        self.cap = int(capacity)
        self.lock = threading.Lock()
        self.data = OrderedDict()
    def _evict(self):
        while len(self.data) > self.cap:
            self.data.popitem(last=False)
    def get(self, key):
        now = time.time()
        with self.lock:
            if key in self.data:
                ts, val = self.data.pop(key)
                if now - ts <= self.ttl:
                    self.data[key] = (ts, val)
                    return val
            return None
    def set(self, key, value):
        with self.lock:
            self.data[key] = (time.time(), value)
            self._evict()

_ai_rl  = _RateLimiter(min_interval_sec=AI_MIN_INTERVAL, max_per_minute=AI_MAX_PER_MIN)
_ai_cache = _AICache(ttl_sec=AI_CACHE_TTL_SEC, capacity=256)

def _ai_cache_key(model, messages):
    try:
        payload = json.dumps({"m": model, "msgs": messages}, ensure_ascii=False, sort_keys=True)
    except Exception:
        payload = str(messages)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()

# --------------- Single-point AI call
def ai_chat(messages):
    global AI_CALLS_ENABLED
    if not AI_CALLS_ENABLED:
        return "(AI disabled — enable in Settings.)"
    if openai_client is None or not OPENAI_API_KEY:
        return "(AI disabled — missing API key.)"

    ck = _ai_cache_key(OPENAI_MODEL, messages)
    cached = _ai_cache.get(ck)
    if cached is not None:
        return cached

    if not _ai_rl.allow():
        return "(AI skipped — rate limit; using cached/formula.)"

    try:
        resp = openai_client.chat.completions.create(
            model=OPENAI_MODEL,
            messages=messages
        )
        out = resp.choices[0].message.content.strip()
        _ai_cache.set(ck, out)
        return out
    except Exception as e:
        msg = str(e)
        if ("insufficient_quota" in msg) or ("exceeded your current quota" in msg) or ("code: 429" in msg):
            AI_CALLS_ENABLED = False
            return "(AI error: insufficient quota — AI disabled; switching to formula.)"
        return f"(AI error: {e})"

def ai_analyze(title: str, body_prompt: str):
    sysmsg = "You are a precise, data-driven pharma market analyst writing in clear English."
    user = f"{title}\n\n{body_prompt}"
    return ai_chat([
        {"role": "system", "content": sysmsg},
        {"role": "user",   "content": user},
    ])

# --------------- Translation helpers
def translate_fa_to_en(text_fa: str) -> str:
    if not text_fa: return ""
    if HAS_TRANSLATOR:
        try: return GoogleTranslator(source='fa', target='en').translate(text_fa) or text_fa
        except Exception: return text_fa
    return text_fa

def translate_if_needed_drug(name: str) -> str:
    if is_arabic_text(name):
        try:
            en = translate_fa_to_en(name)
            return en or name
        except Exception:
            return name
    return name

# --------------- FA-first company detection + brand/ingredient routing + AI code executor

def _tokenize_fa(s: str):
    return [t for t in re.split(r"[^\w\u0600-\u06FF]+", s) if len(t) >= 3]

def find_company_candidates_fa(question_fa: str, max_out=3):
    try:
        DF, _ = get_data()
    except Exception:
        return []
    q_norm = normalize_fa(question_fa).lower()
    tokens = set(_tokenize_fa(q_norm))
    if "Licensee_norm" not in DF.columns: return []
    uniq = DF[["Licensee","Licensee_norm"]].drop_duplicates().dropna()
    candidates = []
    for _, row in uniq.iterrows():
        lic = str(row["Licensee"])
        lic_n = str(row["Licensee_norm"]).lower()
        score = 0.0
        if lic_n and (lic_n in q_norm or q_norm in lic_n):
            score += 2.0
        lic_tokens = set(_tokenize_fa(lic_n))
        overlap = len(tokens & lic_tokens)
        if overlap: score += 1.0 + 0.2 * overlap
        if score > 0: candidates.append((lic, score))
    candidates.sort(key=lambda x: x[1], reverse=True)
    return candidates[:max_out]

def detect_entity_and_route(question: str):
    """
    Routing priority:
    - Try company first (FA-first). If not matched:
      * If the question explicitly mentions 'brand/نام تجاری' → try brand first, then ingredient.
      * Otherwise → try ingredient (ING1–3, optionally Generic Name fallback), then brand.
    """
    # 0) Company (FA-first exact/overlap)
    cand = find_company_candidates_fa(question, max_out=1)
    if cand:
        return {"function": "analyze_company", "args": [cand[0][0]]}
    try:
        DF, _ = get_data()
        q_norm = normalize_fa(question).lower()
        hits = DF[DF["Licensee_norm"].str.contains(q_norm, na=False)]
        if not hits.empty:
            company = hits["Licensee"].iloc[0]
            return {"function": "analyze_company", "args": [company]}
    except Exception:
        pass

    # 1) Brand vs Ingredient mode
    try:
        DF, _ = get_data()
    except Exception:
        return None
    q_norm = normalize_fa(question).lower()
    q_en = translate_fa_to_en(question)
    q_en_norm = normalize_fa(q_en).lower()

    brand_mode = any(w in q_norm for w in ["برند", "نام تجاری", "brand"])

    def search_brand():
        if "Brand Name_norm" in DF.columns and DF["Brand Name_norm"].astype(str).str.strip().any():
            m1 = DF[DF["Brand Name_norm"].str.contains(q_norm, na=False)]
            m2 = DF[DF["Brand Name_norm"].str.contains(q_en_norm, na=False)]
            match_brand = pd.concat([m1, m2]).drop_duplicates()
            if not match_brand.empty:
                brand = (match_brand["Brand Name"].dropna().astype(str).mode())
                if not brand.empty:
                    return {"function": "summarize_brand", "args": [brand.iloc[0]]}
        return None

    def search_ingredient():
        drug_cols = ["ING1_norm","ING2_norm","ING3_norm"]
        aux_cols = ["Generic Name_norm"] if "Generic Name_norm" in DF.columns else []
        for col in drug_cols + aux_cols:
            if col not in DF.columns:
                continue
            if DF[col].str.contains(q_en_norm, na=False).any() or DF[col].str.contains(q_norm, na=False).any():
                return {"function":"summarize_drug","args":[q_en if q_en else question]}
        return None

    if brand_mode:
        return search_brand() or search_ingredient()

    return search_ingredient() or search_brand()

def _safe_exec_python(user_code: str, env: dict):
    from contextlib import redirect_stdout
    import io as _io
    allowed_builtins = {
        "print": print, "len": len, "range": range, "min": min, "max": max, "sum": sum, "abs": abs,
        "round": round, "sorted": sorted, "enumerate": enumerate, "zip": zip, "map": map, "filter": filter,
        "any": any, "all": all
    }
    glob = {"__builtins__": allowed_builtins, "pd": pd, "np": np}
    glob.update(env or {})
    buf = _io.StringIO()
    try:
        with redirect_stdout(buf):
            exec(user_code, glob, glob)
    except Exception as e:
        return "", None, e
    out = buf.getvalue()
    res = glob.get("result", None)
    return out, res, None

def ai_code_answer(question: str):
    try:
        DF, _ = get_data()
    except Exception as e:
        return f"⚠️ Data not loaded, cannot run analysis: {e}"
    sysmsg = (
        "You are a Python data scientist working with a pandas DataFrame named DF that contains pharma sales.\n"
        "Only use pandas/numpy/DF already available. Do NOT read files or import external libraries.\n"
        "Goal: answer the user's question clearly. Always:\n"
        "- Create a concise printed summary in Persian if the input is Persian, else English.\n"
        "- If relevant, compute a tidy pandas result (Series or DataFrame) and assign to variable `result`.\n"
        "- Keep code under ~80 lines. Use clear variable names."
    )
    usr = f"Question:\n{question}\n\nHelpful columns in DF: {list(DF.columns)}\n"
    code = ai_chat([
        {"role": "system", "content": sysmsg},
        {"role": "user", "content": usr}
    ])
    m = re.search(r"```(?:python)?\s*(.*?)```", code, flags=re.S)
    code_to_run = m.group(1) if m else code
    out, res, err = _safe_exec_python(code_to_run, {"DF": DF})
    if err:
        return f"⚠️ خطا در اجرای تحلیل خودکار: {err}"
    lines = []
    if out.strip(): lines.append(out.strip())
    if isinstance(res, pd.DataFrame) and not res.empty:
        preview = res.head(20); lines.append("\nنتیجه (نمونه):\n" + preview.to_string(index=False))
    elif isinstance(res, pd.Series) and not res.empty:
        lines.append("\nنتیجه (نمونه):\n" + res.head(20).to_string())
    elif isinstance(res, (list, tuple)) and len(res) > 0:
        lines.append("\nنتیجه: " + str(res[:10]))
    elif isinstance(res, dict) and len(res) > 0:
        items = list(res.items())[:10]
        lines.append("\nنتیجه: " + ", ".join([f"{k}: {v}" for k, v in items]))
    elif isinstance(res, (str, int, float)) and str(res).strip():
        lines.append("\nنتیجه: " + str(res))
    final_text = "\n\n".join([l for l in lines if l])
    return final_text or "✅ تحلیل انجام شد، اما خروجی معناداری برای نمایش وجود نداشت."

# --------------- ATC helpers
def atc_level2(code: str) -> str:
    c = str(code).upper().strip()
    c = "".join(ch for ch in c if ch.isalnum())
    m = re.match(r"^([A-Z]\d{2})", c)
    if m: return m.group(1)
    return c[:3] if len(c) >= 3 else c

def atc_level3(code: str) -> str:
    c = str(code).upper().strip()
    c = "".join(ch for ch in c if ch.isalnum())
    m = re.match(r"^([A-Z]\d{2}[A-Z])", c)
    if m: return m.group(1)
    return c[:4] if len(c) >= 4 else c

# --------------- Concentration metrics
def concentration_metrics(shares_series: pd.Series):
    total = shares_series.sum()
    if total <= 0 or shares_series.empty:
        return dict(HHI=0.0, CR3=0.0, CR5=0.0, label="Low", note="No data")
    shares = (shares_series / total).sort_values(ascending=False)
    HHI = float((shares.pow(2)).sum() * 10000)
    CR3 = float(shares.head(3).sum() * 100)
    CR5 = float(shares.head(5).sum() * 100)
    label = "Low" if HHI < 1500 else ("Moderate" if HHI <= 2500 else "High")
    return dict(HHI=HHI, CR3=CR3, CR5=CR5, label=label, note="DoJ: <1500 Low, 1500–2500 Moderate, >2500 High")

# --------------- Forecast (formula)
def _forecast_formula(years: pd.Index, values: pd.Series, horizon=5, log=True):
    idx = pd.Series(sorted(list(years)))
    y = pd.Series(values).reindex(idx, fill_value=np.nan).astype(float)
    x = np.arange(len(idx), dtype=float)
    yy = np.log(np.clip(y, 1e-6, None)) if log else y.copy()
    if yy.isna().all():
        return pd.Series(index=[idx.iloc[-1] + i for i in range(1, horizon+1)], data=0.0)
    yy = yy.fillna(method="ffill").fillna(method="bfill")
    try:
        b1, b0 = np.polyfit(x, yy, 1)
    except Exception:
        b1, b0 = 0.0, float(yy.iloc[-1])
    future_years = [int(idx.iloc[-1]) + i for i in range(1, horizon+1)]
    x_future = np.arange(len(idx), len(idx)+horizon, dtype=float)
    yhat = b1*x_future + b0
    if log: yhat = np.exp(yhat)
    yhat = np.maximum(yhat, 0.0)
    return pd.Series(data=yhat, index=future_years)

# --------------- Core analytics — Ingredient (active)
def compute_drug_insights(ingredient: str):
    DF, ATC = get_data()
    ing_norm = normalize_fa(ingredient).lower()

    # فیلتر کردن داده‌ها بر اساس نام دارو (ING1-3_norm)
    sub = DF[DF.apply(
        lambda r: ing_norm in (
            r.get("ING1_norm", "") + " " +
            r.get("ING2_norm", "") + " " +
            r.get("ING3_norm", "")
        ),
        axis=1
    )]
    if sub.empty:
        return {"empty": True, "name": ingredient}

    # آمار کلی
    total_units = sub["Units"].sum()
    total_value = sub["Value"].sum()
    avg_price = total_value / total_units if total_units else 0

    # آمار سالانه
    y = sub.groupby("Year")[["Units", "Value"]].sum().sort_index()
    y["Avg Price"] = (y["Value"].replace(0, np.nan) / y["Units"].replace(0, np.nan)).fillna(0)
    y["YoY Units %"] = yoy(y["Units"]) * 100
    y["YoY Value %"] = yoy(y["Value"]) * 100

    units_cagr = cagr(y["Units"].iloc[0], max(y["Units"].iloc[-1], 1), len(y)) if not y.empty else 0.0
    value_cagr = cagr(max(y["Value"].iloc[0], 1), max(y["Value"].iloc[-1], 1), len(y)) if not y.empty else 0.0
    price_cagr = cagr(max(y["Avg Price"].iloc[0], 1), max(y["Avg Price"].iloc[-1], 1), len(y)) if not y.empty else 0.0

    base_units = y["Units"].iloc[0] or 1
    base_value = y["Value"].iloc[0] or 1
    y["Units Index (Base=100)"] = (y["Units"] / base_units) * 100
    y["Value Index (Base=100)"] = (y["Value"] / base_value) * 100

    # Forecast 5y
    fc_units = _forecast_formula(y.index, y["Units"], 5, log=True)
    fc_value = _forecast_formula(y.index, y["Value"], 5, log=True)
    fc_price = _forecast_formula(y.index, y["Avg Price"], 5, log=True)

    # dosage forms
    if "Dosage Form" in sub.columns and sub["Dosage Form"].astype(str).str.strip().any():
        form_dist = (sub["Dosage Form"]
                     .replace("", np.nan)
                     .dropna()
                     .value_counts(normalize=True) * 100)
        form_text = "\n".join(
            f"- {fa_display(k)}: {v:.1f}%"
            for k, v in form_dist.items()
        ) if not form_dist.empty else "—"
    else:
        form_text = "—"

    # combos (ترکیب‌های دارویی)
    combo = sub.copy()
    for c in ["ING1", "ING2", "ING3"]:
        if c not in combo.columns:
            combo[c] = ""
    combo["Combo"] = combo[["ING1", "ING2", "ING3"]].apply(
        lambda r: " + ".join([x for x in r if str(x).strip()]),
        axis=1
    )
    combo_stats = combo.groupby("Combo")["Units"].sum().sort_values(ascending=False)
    combo_text = (
        "\n".join(
            f"- {k} — {(v / total_units * 100):.1f}%"
            for k, v in combo_stats.items()
        )
        if total_units > 0 else "—"
    )

    # لیدرهای همین ingredient (بر اساس Units)
    leader_co_ing = sub.groupby("Licensee")["Units"].sum().sort_values(ascending=False).head(10)
    leader_co_ing_text = (
        "\n".join(f"- {fa_display(k)}: {fmt_int(v)}" for k, v in leader_co_ing.items())
        if not leader_co_ing.empty else "—"
    )

    # ======= Market shares (last year) (سهم بازار کل بازار در سال آخر)
    last_year = int(y.index.max())
    df_last = DF[DF["Year"] == last_year]
    overall_units_last = float(df_last["Units"].sum())
    overall_value_last = float(df_last["Value"].sum())

    drug_units_last = float(sub[sub["Year"] == last_year]["Units"].sum())
    drug_value_last = float(sub[sub["Year"] == last_year]["Value"].sum())

    ms_total_units = (drug_units_last / overall_units_last * 100) if overall_units_last > 0 else 0.0
    ms_total_value = (drug_value_last / overall_value_last * 100) if overall_value_last > 0 else 0.0

    fig_pie_total_units = pie_chart_two(
        f"Total Market Share (Units, {last_year}) — {ingredient}",
        f"{ingredient}", drug_units_last, "Others",
        max(overall_units_last - drug_units_last, 0.0)
    )
    fig_pie_total_value = pie_chart_two(
        f"Total Market Share (Value, {last_year}) — {ingredient}",
        f"{ingredient}", drug_value_last, "Others",
        max(overall_value_last - drug_value_last, 0.0)
    )

    # ======= ATC cluster (استفاده از ATC.xlsx مثل نسخه‌ی paste) =======
    rivals_text = "—"
    ref_text = "—"
    leader_co_atc_text = "—"
    leader_drug_text = "—"
    competitors_units_text = "—"
    competitors_value_text = "—"
    pie_atc3_units = None
    pie_atc3_value = None
    ms_atc3_units = 0.0
    ms_atc3_value = 0.0

    try:
        # کد ATC اصلی این دارو از DF (sales)
        code = sub["ATC"].dropna().astype(str).str.strip().replace("", np.nan).dropna().iloc[0]

        # پیدا کردن ستون‌های کد ATC و سطح ۳ در فایل ATC.xlsx
        lvl3_col, atc_code_col = None, None
        for c in ATC.columns:
            if ("کد" in c and "سطح" in c and "3" in c) or ("Level 3" in c and "ATC" in c):
                lvl3_col = c
                break
        for c in ATC.columns:
            nk = normkey(c)
            if ("atc" in nk and "code" in nk) or ("کد" in c and "ATC" in c):
                atc_code_col = c
                break
        if atc_code_col is None:
            atc_code_col = ATC.columns[0]

        # سطح ۳ این کد در جدول ATC
        lvl3 = ATC.loc[
            ATC[atc_code_col].astype(str) == str(code),
            lvl3_col
        ].squeeze() if lvl3_col else np.nan

        if pd.notna(lvl3):
            # همه کدهای ATC در همین سطح ۳ (رقبا + خودش)
            rivals_codes = ATC[ATC[lvl3_col] == lvl3][atc_code_col].astype(str).tolist()
            rivals_codes = [c for c in rivals_codes if str(c).strip()]  # پاک‌سازی
            # رقبا = همه کدها به جز خود دارو
            codes_rivals_only = [c for c in rivals_codes if str(c) != str(code)]

            # نام ژنریک رقبا از DF
            rivals_names = (
                DF[DF["ATC"].astype(str).isin(codes_rivals_only)]["Generic Name"]
                .dropna()
                .unique()
            )
            rivals_text = ", ".join(map(str, rivals_names)) if len(rivals_names) > 0 else "—"

            # خوشهٔ کامل ATC: خود دارو + رقبا
            atc_cluster = DF[DF["ATC"].astype(str).isin(rivals_codes)]

            # سهم این ingredient داخل خوشه ATC در سال آخر
            cluster_last = atc_cluster[atc_cluster["Year"] == last_year]
            cluster_units_last = float(cluster_last["Units"].sum())
            cluster_value_last = float(cluster_last["Value"].sum())
            ms_atc3_units = (drug_units_last / cluster_units_last * 100) if cluster_units_last > 0 else 0.0
            ms_atc3_value = (drug_value_last / cluster_value_last * 100) if cluster_value_last > 0 else 0.0

            # Top-10 رقبا بر اساس VALUE در سال آخر
            cl_g_all = cluster_last.groupby("Generic Name")[["Units", "Value"]].sum().dropna(how="all")
            if not cl_g_all.empty:
                cl_g_all = cl_g_all.sort_values("Value", ascending=False)
                TOP_N = 10
                cl_g_top = cl_g_all.head(TOP_N)

                tot_u_top = float(cl_g_top["Units"].sum()) if not cl_g_top.empty else 0.0
                tot_v_top = float(cl_g_top["Value"].sum()) if not cl_g_top.empty else 0.0

                gens_ing = set(sub["Generic Name"].dropna().astype(str).unique().tolist())
                comp_lines_units = []
                comp_lines_value = []

                for g, row in cl_g_top.iterrows():
                    tag = " (target)" if g in gens_ing else ""
                    share_u = (float(row["Units"]) / tot_u_top * 100) if tot_u_top > 0 else 0.0
                    share_v = (float(row["Value"]) / tot_v_top * 100) if tot_v_top > 0 else 0.0
                    comp_lines_units.append(
                        f"- {fa_display(g)}{tag}: {fmt_int(row['Units'])}  ({share_u:.1f}%)"
                    )
                    comp_lines_value.append(
                        f"- {fa_display(g)}{tag}: {fmt_int(row['Value'])}  ({share_v:.1f}%)"
                    )

                competitors_units_text = "\n".join(comp_lines_units) if comp_lines_units else "—"
                competitors_value_text = "\n".join(comp_lines_value) if comp_lines_value else "—"

                # نمودارهای pie خوشه ATC (براساس Top-10 value)
                pie_atc3_units = pie_chart(
                    f"ATC L3 Share (Units, {last_year}) — {ingredient}",
                    labels=cl_g_top.index.tolist(),
                    values=cl_g_top["Units"].tolist(),
                    top_k=TOP_N
                )
                pie_atc3_value = pie_chart(
                    f"ATC L3 Share (Value, {last_year}) — {ingredient}",
                    labels=cl_g_top.index.tolist(),
                    values=cl_g_top["Value"].tolist(),
                    top_k=TOP_N
                )

            # لیدرها در کل خوشه ATC (همه سال‌ها)
            leader_co_atc = atc_cluster.groupby("Licensee")["Units"].sum().sort_values(ascending=False).head(10)
            if not leader_co_atc.empty:
                leader_co_atc_text = "\n".join(
                    f"- {fa_display(k)}: {fmt_int(v)}"
                    for k, v in leader_co_atc.items()
                )

            leader_drug = atc_cluster.groupby("Generic Name")["Units"].sum().sort_values(ascending=False).head(10)
            if not leader_drug.empty:
                leader_drug_text = "\n".join(
                    f"- {k}: {fmt_int(v)}"
                    for k, v in leader_drug.items()
                )

            # رفرنس کامل از جدول ATC.xlsx برای همین کد
            ref_row = ATC[ATC[atc_code_col].astype(str) == str(code)]
            if not ref_row.empty:
                ref = ref_row.iloc[0]
                ref_lines = [
                    f"- {fa_display(str(col))}: {fa_display(str(ref[col]))}"
                    for col in ATC.columns if col in ref.index
                ]
                ref_text = "\n".join(ref_lines)

    except Exception as e:
        # در صورت خطا، همه چیز روی مقدار پیش‌فرض می‌ماند
        print(f"[ATC block error] {e}")

    # شاخص تمرکز (HHI/CR3/CR5) بر اساس سهم شرکت‌ها در این ingredient
    conc = concentration_metrics(sub.groupby("Licensee")["Units"].sum())

    return {
        "empty": False,
        "name": ingredient,
        "sub": sub,
        "yearly": y,
        "units_cagr": units_cagr,
        "value_cagr": value_cagr,
        "price_cagr": price_cagr,
        "total_units": total_units,
        "total_value": total_value,
        "avg_price": avg_price,
        "form_text": form_text,
        "combo_text": combo_text,
        "leader_co_ing_text": leader_co_ing_text,
        "rivals_text": rivals_text,
        "ref_text": ref_text,
        "leader_co_atc_text": leader_co_atc_text,
        "leader_drug_text": leader_drug_text,
        "concentration": conc,
        "fc_units": fc_units,
        "fc_value": fc_value,
        "fc_price": fc_price,
        "last_year": last_year,
        "ms_total_units": ms_total_units,
        "ms_total_value": ms_total_value,
        "fig_pie_total_units": fig_pie_total_units,
        "fig_pie_total_value": fig_pie_total_value,
        "ms_atc3_units": ms_atc3_units,
        "ms_atc3_value": ms_atc3_value,
        "competitors_units_text": competitors_units_text,
        "competitors_value_text": competitors_value_text,
        "fig_pie_atc3_units": pie_atc3_units,
        "fig_pie_atc3_value": pie_atc3_value,
    }
def compute_company_insights(co: str):
    DF, ATC = get_data()
    co_norm = normalize_fa(co).lower()

    # 1) زیرمجموعه‌ی شرکت
    if "Licensee_norm" not in DF.columns:
        return {"empty": True, "name": co, "note": "Licensee_norm column missing"}
    sub = DF[DF["Licensee_norm"].str.contains(co_norm, na=False)]
    if sub.empty:
        return {"empty": True, "name": co}

    # 2) آمار کلی
    total_units = float(sub["Units"].sum())
    total_value = float(sub["Value"].sum())
    avg_price = total_value / total_units if total_units > 0 else 0.0

    # 3) آمار سالانه + رشد
    y = sub.groupby("Year")[["Units", "Value"]].sum().sort_index()
    if y.empty:
        return {"empty": True, "name": co, "note": "No yearly data"}

    y["Avg Price"] = (y["Value"] / y["Units"].replace(0, np.nan)).fillna(0)
    y["YoY Units %"] = yoy(y["Units"]) * 100
    y["YoY Value %"] = yoy(y["Value"]) * 100

    n_years = len(y)
    units_cagr = cagr(y["Units"].iloc[0], y["Units"].iloc[-1], n_years) if n_years > 1 and y["Units"].iloc[0] > 0 else 0.0
    value_cagr = cagr(y["Value"].iloc[0], y["Value"].iloc[-1], n_years) if n_years > 1 and y["Value"].iloc[0] > 0 else 0.0
    price_cagr = cagr(y["Avg Price"].iloc[0], y["Avg Price"].iloc[-1], n_years) if n_years > 1 else 0.0

    # 4) سهم بازار کل در سال آخر
    last_year = int(y.index.max())
    df_last = DF[DF["Year"] == last_year]
    co_u_last = float(sub[sub["Year"] == last_year]["Units"].sum())
    co_v_last = float(sub[sub["Year"] == last_year]["Value"].sum())
    ov_u_last = float(df_last["Units"].sum())
    ov_v_last = float(df_last["Value"].sum())
    ms_units = (co_u_last / ov_u_last * 100) if ov_u_last > 0 else 0.0
    ms_value = (co_v_last / ov_v_last * 100) if ov_v_last > 0 else 0.0

    # 5) تاپ جنریک‌ها
    top_g = sub.groupby("Generic Name")["Units"].sum().sort_values(ascending=False).head(10)
    if total_units > 0 and not top_g.empty:
        top_generics_text = "\n\n".join(
            f"- {fa_display(k)}: {fmt_int(v)}  ({v / total_units * 100:.1f}%)"
            for k, v in top_g.items()
        )
    else:
        top_generics_text = "—"

    # 6) تاپ برندها
    if "Brand Name" in sub.columns:
        top_b = sub.groupby("Brand Name")["Units"].sum().sort_values(ascending=False).head(10)
        top_brands_text = "\n\n".join(
            f"- {fa_display(k)}: {fmt_int(v)}"
            for k, v in top_b.items()
        ) if not top_b.empty else "—"
    else:
        top_brands_text = "—"

    # 7) فرم‌های دارویی
    form_text = "—"
    if "Dosage Form" in sub.columns and sub["Dosage Form"].astype(str).str.strip().any():
        form_dist = (sub["Dosage Form"]
                     .replace("", np.nan)
                     .dropna()
                     .value_counts(normalize=True) * 100)
        if not form_dist.empty:
            form_text = "\n\n".join(
                f"- {fa_display(k)}: {v:.1f}%"
                for k, v in form_dist.head(10).items()
            )

    # 8) کامبو (ING1–3)
    for ing in ["ING1", "ING2", "ING3"]:
        if ing not in sub.columns:
            sub[ing] = ""
    sub["Combo"] = sub[["ING1", "ING2", "ING3"]].apply(
        lambda r: " + ".join([str(x).strip() for x in r if str(x).strip()]),
        axis=1
    )
    top_combo = sub.groupby("Combo")["Units"].sum().sort_values(ascending=False).head(5)
    combo_text = "\n\n".join(
        f"- {fa_display(k)}: {fmt_int(v)}"
        for k, v in top_combo.items()
    ) if not top_combo.empty else "—"

    # 9) تمرکز پرتفوی (HHI روی جنریک‌ها)
    conc = concentration_metrics(sub.groupby("Generic Name")["Units"].sum())
    fig_conc = pie_chart(
        f"Concentration (Top Generics Units) — {co}",
        labels=top_g.index.tolist()[:5],
        values=top_g.values.tolist()[:5],
        top_k=5
    ) if not top_g.empty else None

    # 10) ATC L3 در پرتفوی شرکت
    if "ATC" in sub.columns:
        sub["ATC_L3"] = sub["ATC"].astype(str).apply(atc_level3)
    else:
        sub["ATC_L3"] = ""

    top_atc = sub["ATC_L3"].value_counts().head(5)
    if total_units > 0 and not top_atc.empty:
        top_atc_text = "\n\n".join(
            f"- {k}: {fmt_int(v)}  ({v / total_units * 100:.1f}%)"
            for k, v in top_atc.items()
        )
    else:
        top_atc_text = "—"

    # 11) Peers بر اساس ATC L3 (بازار کل)
    peers_text = "—"
    if "ATC" in DF.columns and not top_atc.empty:
        if "ATC_L3" not in DF.columns:
            DF["ATC_L3"] = DF["ATC"].astype(str).apply(atc_level3)

        peers_lines = []
        for atc3, _cnt in top_atc.items():
            cluster = DF[DF["ATC_L3"] == atc3]
            if cluster.empty:
                continue

            cls_units = float(cluster["Units"].sum())
            co_units_cls = float(sub[sub["ATC_L3"] == atc3]["Units"].sum())
            share = co_units_cls / cls_units * 100 if cls_units > 0 else 0.0
            if share <= 10:
                continue

            rivals = cluster.groupby("Licensee")["Units"].sum().sort_values(ascending=False).head(5)
            peers_lines.append(
                f"ATC {atc3} — share {share:.1f}%:\n" +
                "\n".join(f"  - {fa_display(k)}: {fmt_int(v)}" for k, v in rivals.items())
            )

        if peers_lines:
            peers_text = "\n\n".join(peers_lines)

    # 12) Forecast (ایمن)
    try:
        fc_u = _forecast_formula(y.index, y["Units"], 5, log=True)
        fc_v = _forecast_formula(y.index, y["Value"], 5, log=True)
        fc_p = _forecast_formula(y.index, y["Avg Price"], 5, log=False)
        fc_df = pd.DataFrame(
            {"Units": fc_u.values, "Value": fc_v.values, "Avg Price": fc_p.values},
            index=fc_u.index
        )
        y_fc = pd.concat([y, fc_df])
    except Exception:
        y_fc = y

    # 13) نمودارهای سهم بازار و تاپ جنریک‌ها
    fig_ms_u = pie_chart_two(
        f"Total Market Share (Units, {last_year}) — {co}",
        co, co_u_last, "Others", max(ov_u_last - co_u_last, 0.0)
    )
    fig_ms_v = pie_chart_two(
        f"Total Market Share (Value, {last_year}) — {co}",
        co, co_v_last, "Others", max(ov_v_last - co_v_last, 0.0)
    )
    fig_top_g = pie_chart(
        f"Top Generics (Units) — {co}",
        labels=top_g.index.tolist(),
        values=top_g.values.tolist(),
        top_k=10
    ) if not top_g.empty else None

    return {
        "empty": False,
        "name": co,
        "yearly": y,
        "yearly_fc": y_fc,
        "total_units": total_units,
        "total_value": total_value,
        "avg_price": avg_price,
        "units_cagr": units_cagr,
        "value_cagr": value_cagr,
        "price_cagr": price_cagr,
        "ms_total_units": ms_units,
        "ms_total_value": ms_value,
        "last_year": last_year,
        "top_generics_text": top_generics_text,
        "top_brands_text": top_brands_text,
        "form_text": form_text,
        "combo_text": combo_text,
        "top_atc_text": top_atc_text,
        "peers_text": peers_text,
        "concentration": conc,
        "fig_ms_units": fig_ms_u,
        "fig_ms_value": fig_ms_v,
        "fig_top_generics": fig_top_g,
        "fig_concentration": fig_conc,
    }

def compute_brand_insights(brand: str):
    DF, ATC = get_data()
    bq = normalize_fa(brand).lower()
    if "Brand Name_norm" not in DF.columns:
        return {"empty": True, "name": brand, "note": "Brand column not present"}
    sub = DF[DF["Brand Name_norm"].str.contains(bq, na=False)].copy()
    if sub.empty:
        return {"empty": True, "name": brand}

    total_units = sub["Units"].sum()
    total_value = sub["Value"].sum()
    avg_price = total_value / total_units if total_units else 0

    y = sub.groupby("Year")[["Units","Value"]].sum().sort_index()
    y["Avg Price"] = (y["Value"].replace(0, np.nan) / y["Units"].replace(0, np.nan)).fillna(0)
    y["YoY Units %"] = yoy(y["Units"]) * 100
    y["YoY Value %"] = yoy(y["Value"]) * 100

    units_cagr = cagr(y["Units"].iloc[0], max(y["Units"].iloc[-1], 1), len(y)) if not y.empty else 0.0
    value_cagr = cagr(max(y["Value"].iloc[0], 1), max(y["Value"].iloc[-1], 1), len(y)) if not y.empty else 0.0
    price_cagr = cagr(max(y["Avg Price"].iloc[0], 1), max(y["Avg Price"].iloc[-1], 1), len(y)) if not y.empty else 0.0

    fc_units = _forecast_formula(y.index, y["Units"], 5, log=True)
    fc_value = _forecast_formula(y.index, y["Value"], 5, log=True)
    fc_price = _forecast_formula(y.index, y["Avg Price"], 5, log=True)

    last_year = int(y.index.max())
    df_last = DF[DF["Year"] == last_year]
    brand_units_last = float(sub[sub["Year"] == last_year]["Units"].sum())
    brand_value_last = float(sub[sub["Year"] == last_year]["Value"].sum())
    overall_units_last = float(df_last["Units"].sum())
    overall_value_last = float(df_last["Value"].sum())
    ms_total_units = (brand_units_last/overall_units_last*100) if overall_units_last>0 else 0.0
    ms_total_value = (brand_value_last/overall_value_last*100) if overall_value_last>0 else 0.0

    # ATC context
    if "ATC" in sub.columns:
        sub["ATC_L3"] = sub["ATC"].astype(str).apply(atc_level3)
    else:
        sub["ATC_L3"] = ""
    atc3 = sub["ATC_L3"].mode().iloc[0] if not sub["ATC_L3"].empty else None

    pie_total_units = pie_chart_two(
        f"Total Market Share (Units, {last_year}) — {brand}",
        f"{brand}", brand_units_last, "Others", max(overall_units_last - brand_units_last, 0.0)
    )
    pie_total_value = pie_chart_two(
        f"Total Market Share (Value, {last_year}) — {brand}",
        f"{brand}", brand_value_last, "Others", max(overall_value_last - brand_value_last, 0.0)
    )

    return {
        "empty": False, "name": brand, "sub": sub, "yearly": y,
        "units_cagr": units_cagr, "value_cagr": value_cagr, "price_cagr": price_cagr,
        "total_units": total_units, "total_value": total_value, "avg_price": avg_price,
        "last_year": last_year, "ms_total_units": ms_total_units, "ms_total_value": ms_total_value,
        "fig_pie_total_units": pie_total_units, "fig_pie_total_value": pie_total_value,
        "fc_units": fc_units, "fc_value": fc_value, "fc_price": fc_price
    }

def build_drug_report_text(ins, ai_block=""):
    y = ins['yearly'].copy()
    for c in ["Units","Value","Avg Price"]:
        if c in y.columns: y[c] = y[c].fillna(0)

    y_table = y[["Units","Value","Avg Price","YoY Units %","YoY Value %","Units Index (Base=100)","Value Index (Base=100)"]].copy()
    y_table["Units"] = y_table["Units"].apply(fmt_int)
    y_table["Value"] = y_table["Value"].apply(fmt_int)
    y_table["Avg Price"] = y_table["Avg Price"].apply(fmt_int)
    y_lines = ["Year | Units | Value | Avg Price | YoY Units% | YoY Value% | UnitsIdx | ValueIdx"]
    for yr, row in y_table.iterrows():
        y_lines.append(f"{yr} | {row['Units']} | {row['Value']} | {row['Avg Price']} | {row['YoY Units %']:.1f}% | {row['YoY Value %']:.1f}% | {row['Units Index (Base=100)']:.1f} | {row['Value Index (Base=100)']:.1f}")
    y_text = "\n".join(y_lines)

    fc_lines = ["Year | Units (fc) | Value (fc) | Price (fc)"]
    for yr in ins["fc_units"].index:
        fc_lines.append(f"{yr} | {fmt_int(ins['fc_units'].loc[yr])} | {fmt_int(ins['fc_value'].loc[yr])} | {fmt_int(ins['fc_price'].loc[yr])}")
    fc_text = "\n".join(fc_lines)

    conc = ins["concentration"]
    conc_block = f"Concentration — HHI: {conc['HHI']:.0f} ({conc['label']}); CR3: {conc['CR3']:.1f}% | CR5: {conc['CR5']:.1f}%\n{conc.get('note','')}"

    ms_total_block = f"Total Market Share ({ins['last_year']}): Units {fmt_pct4(ins['ms_total_units'])} | Value {fmt_pct4(ins['ms_total_value'])}"
    ms_atc3_block =  f"ATC L3 Share ({ins['last_year']}): Units {fmt_pct4(ins['ms_atc3_units'])} | Value {fmt_pct4(ins['ms_atc3_value'])}"

    text = f"""
DRUG ANALYSIS — {fa_display(ins['name'])}

SUMMARY
- Total Units: {fmt_int(ins['total_units'])} | Total Value: {fmt_int(ins['total_value'])} | Avg Price: {fmt_int(ins['avg_price'])}
- CAGR — Units: {ins['units_cagr']:.2%} | Value: {ins['value_cagr']:.2%} | Price: {ins['price_cagr']:.2%}
{conc_block}
{ms_total_block}
{ms_atc3_block}

YEARLY BREAKDOWN
{y_text}

5-YEAR FORECAST (formula)
{fc_text}

LEADERS — This Ingredient (by Units)
{ins['leader_co_ing_text']}

LEADERS — ATC L3 Cluster (by Generic) — All years (Units)
{ins['leader_drug_text']}

LEADERS — ATC L3 Cluster (by Licensee) — All years (Units)
{ins['leader_co_atc_text']}

ATC L3 COMPETITORS — Top 10 (last year, Units)
{ins['competitors_units_text']}

ATC L3 COMPETITORS — Top 10 by Value (last year)
{ins['competitors_value_text']}

COMMON COMBINATIONS
{ins['combo_text']}

DOSAGE FORMS
{ins['form_text']}

PEERS (ATC L3 names)
{ins['rivals_text']}

AI INSIGHT (single call)
{ai_block}
""".strip()
    return text

def summarize_drug(ingredient: str):
    ins = compute_drug_insights(ingredient)
    if ins.get("empty"): return f"❌ No data for “{ingredient}”.", []
    y = ins["yearly"]
    table_txt = "Year,Units,Value,AvgPrice\n" + "\n".join(
        [f"{int(i)},{float(r['Units']):.6f},{float(r['Value']):.6f},{float(r['Avg Price']):.6f}"
         for i,r in y[["Units","Value","Avg Price"]].iterrows()]
    )
    prompt = f"""Provide an English executive brief for ingredient '{ins['name']}'.
Include: trend, drivers, risks, opportunities, leadership interpretation (company & generic), and a 5y outlook.
Use the table below (do NOT recalc in detail; summarize clearly).
TABLE:
{table_txt}
"""
    ai_block = ai_analyze("Ingredient Brief", prompt)

    figs = [
        smart_plot(f"Unit Sales — {ins['name']}", y.index, y["Units"], "Unit Sales"),
        smart_plot(f"Value Sales — {ins['name']}", y.index, y["Value"], "Value Sales"),
        smart_plot(f"Average Price — {ins['name']}", y.index, y["Avg Price"], "Average Price"),
        smart_plot(f"Units Index (Base=100) — {ins['name']}", y.index, y["Units Index (Base=100)"], "Index"),
        smart_plot(f"YoY Unit Growth — {ins['name']}", y.index, y["YoY Units %"], "YoY %"),
        smart_plot(f"Forecast Units (5y) — {ins['name']}", ins["fc_units"].index, ins["fc_units"], "Units (fc)"),
        smart_plot(f"Forecast Value (5y) — {ins['name']}", ins["fc_value"].index, ins["fc_value"], "Value (fc)"),
        smart_plot(f"Forecast Price (5y) — {ins['name']}", ins["fc_price"].index, ins["fc_price"], "Avg Price (fc)"),
    ]
    if ins.get("fig_pie_total_units") is not None: figs.append(ins["fig_pie_total_units"])
    if ins.get("fig_pie_total_value") is not None: figs.append(ins["fig_pie_total_value"])
    if ins.get("fig_pie_atc3_units") is not None: figs.append(ins["fig_pie_atc3_units"])
    if ins.get("fig_pie_atc3_value") is not None: figs.append(ins["fig_pie_atc3_value"])

    text = build_drug_report_text(ins, ai_block)
    return text, figs

# --------------- Brand analytics
def summarize_brand(brand: str):
    ins = compute_brand_insights(brand)
    if ins.get("empty"): return f"❌ No data for brand “{brand}”.", []
    y = ins["yearly"]
    table_txt = "Year,Units,Value,AvgPrice\n" + "\n".join(
        [f"{int(i)},{float(r['Units']):.6f},{float(r['Value']):.6f},{float(r['Avg Price']):.6f}"
         for i,r in y[["Units","Value","Avg Price"]].iterrows()]
    )
    prompt = f"""Provide an English executive brief for brand '{ins['name']}'.
Discuss volume vs value trend, pricing, competitive pressure, and 5y view.
TABLE:
{table_txt}
"""
    ai_block = ai_analyze("Brand Brief", prompt)

    figs = [
        smart_plot(f"Unit Sales — {ins['name']}", y.index, y["Units"], "Units"),
        smart_plot(f"Value Sales — {ins['name']}", y.index, y["Value"], "Value"),
        smart_plot(f"Average Price — {ins['name']}", y.index, y["Avg Price"], "Avg Price"),
        smart_plot(f"Forecast Units (5y) — {ins['name']}", ins["fc_units"].index, ins["fc_units"], "Units (fc)"),
        smart_plot(f"Forecast Value (5y) — {ins['name']}", ins["fc_value"].index, ins["fc_value"], "Value (fc)"),
        smart_plot(f"Forecast Price (5y) — {ins['name']}", ins["fc_price"].index, ins["fc_price"], "Avg Price (fc)"),
        ins["fig_pie_total_units"], ins["fig_pie_total_value"]
    ]

    # برای برند از همان قالب گزارش ماده استفاده می‌کنیم (حاوی بلوک‌های عمومی و خلاصه AI)
    text = build_drug_report_text({
        **ins,
        "leader_co_ing_text": "—",
        "leader_drug_text": "—",
        "leader_co_atc_text": "—",
        "competitors_units_text": "—",
        "competitors_value_text": "—",
        "rivals_text": "—",
        "concentration": {"HHI":0,"CR3":0,"CR5":0,"label":"—","note":""},
        "ms_atc3_units": 0.0,
        "ms_atc3_value": 0.0
    }, ai_block)
    return text, figs

# --------------- Company analytics (enhanced)
def _ensure_atc_levels(df: pd.DataFrame):
    if "ATC_L2" not in df.columns:
        df["ATC_L2"] = df["ATC"].astype(str).apply(atc_level2)
    if "ATC_L3" not in df.columns:
        df["ATC_L3"] = df["ATC"].astype(str).apply(atc_level3)

def _company_peer_overlap(df: pd.DataFrame, base_company: str, thr: float = 0.10):
    """Return list of peer companies (excluding self) with Jaccard overlap >= thr over Generic Name sets."""
    df = df.copy()
    nbase = normalize_fa(base_company).lower()
    sub_base = df[df["Licensee_norm"].str.contains(nbase, na=False)]
    if sub_base.empty: return [], set()
    base_set = set(sub_base["Generic Name"].dropna().astype(str).unique())
    peers = []
    all_companies = df["Licensee"].dropna().astype(str).unique().tolist()
    for c in all_companies:
        if normalize_fa(c).lower() == nbase:  # exclude self
            continue
        sub_c = df[df["Licensee"] == c]
        c_set = set(sub_c["Generic Name"].dropna().astype(str).unique())
        if not c_set: continue
        inter = len(base_set & c_set)
        union = len(base_set | c_set)
        jacc = inter/union if union>0 else 0.0
        if jacc >= thr:
            peers.append((c, jacc))
    peers.sort(key=lambda x: x[1], reverse=True)
    return peers, base_set

def analyze_company(company_name: str):
    DF, _ = get_data()
    _ensure_atc_levels(DF)
    n = normalize_fa(company_name).lower()
    sub = DF[DF["Licensee_norm"].str.contains(n, na=False)]
    if sub.empty: return f"❌ Company “{company_name}” not found.", []

    # yearly
    y = sub.groupby("Year")[["Units","Value"]].sum().sort_index()
    y["Avg Price"] = (y["Value"].replace(0,np.nan) / y["Units"].replace(0,np.nan)).fillna(0)
    y["YoY Units %"] = yoy(y["Units"])*100
    y["YoY Value %"] = yoy(y["Value"])*100
    fc_units = _forecast_formula(y.index, y["Units"], 5, log=True)
    fc_value = _forecast_formula(y.index, y["Value"], 5, log=True)
    fc_price = _forecast_formula(y.index, y["Avg Price"], 5, log=True)

    # Top-5 generics
    top5 = sub.groupby("Generic Name")["Units"].sum().sort_values(ascending=False).head(5)
    top5_text = "\n".join(f"- {fa_display(k)}: {fmt_int(v)}" for k,v in top5.items()) if not top5.empty else "—"

    # Forms
    form_text = "—"
    if "Dosage Form" in sub.columns and sub["Dosage Form"].astype(str).str.strip().any():
        form_dist = (sub["Dosage Form"].replace("", np.nan).dropna().value_counts(normalize=True)*100)
        form_text = "\n".join(f"- {fa_display(k)}: {v:.1f}%" for k,v in form_dist.items()) if not form_dist.empty else "—"

    # CAGR & totals
    units_cagr = cagr(y["Units"].iloc[0], y["Units"].iloc[-1], len(y)) if not y.empty else 0.0
    value_cagr = cagr(max(y["Value"].iloc[0],1), max(y["Value"].iloc[-1],1), len(y)) if not y.empty else 0.0
    total_units = sub["Units"].sum()
    total_value = sub["Value"].sum()

    # Last year + total market shares
    last_year = int(y.index.max())
    df_last = DF[DF["Year"] == last_year]
    company_units_last = float(sub[sub["Year"] == last_year]["Units"].sum())
    company_value_last = float(sub[sub["Year"] == last_year]["Value"].sum())
    overall_units_last = float(df_last["Units"].sum())
    overall_value_last = float(df_last["Value"].sum())
    ms_total_units = (company_units_last/overall_units_last*100) if overall_units_last>0 else 0.0
    ms_total_value = (company_value_last/overall_value_last*100) if overall_value_last>0 else 0.0

    fig_pie_total_units = pie_chart_two(
        f"Total Market Share (Units, {last_year}) — {company_name}",
        f"{company_name}", company_units_last, "Others", max(overall_units_last - company_units_last, 0.0)
    )
    fig_pie_total_value = pie_chart_two(
        f"Total Market Share (Value, {last_year}) — {company_name}",
        f"{company_name}", company_value_last, "Others", max(overall_value_last - company_value_last, 0.0)
    )

    # ATC-Level pies for company share among companies in each cluster (L2 & L3) — last year
    def _company_atc_pies(level="L2"):
        col = "ATC_L2" if level=="L2" else "ATC_L3"
        clusters = sub[sub["Year"]==last_year][col].dropna().astype(str).unique().tolist()
        figs_u, figs_v, blocks = [], [], []
        for cl in clusters:
            cluster = DF[(DF["Year"]==last_year) & (DF[col]==cl)]
            if cluster.empty: continue
            g = cluster.groupby("Licensee")[["Units","Value"]].sum()
            g = g.sort_values("Value", ascending=False) if g["Value"].sum()>0 else g.sort_values("Units", ascending=False)
            top10 = g.head(10).copy()
            t_lines_u = []
            t_lines_v = []
            tot_u = float(top10["Units"].sum()) if not top10.empty else 0.0
            tot_v = float(top10["Value"].sum()) if not top10.empty else 0.0
            for lic, row in top10.iterrows():
                su = (float(row["Units"])/tot_u*100) if tot_u>0 else 0.0
                sv = (float(row["Value"])/tot_v*100) if tot_v>0 else 0.0
                tag = " (target)" if normalize_fa(lic).lower() == n else ""
                t_lines_u.append(f"- {fa_display(lic)}{tag}: {fmt_int(row['Units'])} ({su:.1f}%)")
                t_lines_v.append(f"- {fa_display(lic)}{tag}: {fmt_int(row['Value'])} ({sv:.1f}%)")
            block = f"\nATC {level} = {cl}\nUnits (Top10):\n" + ("\n".join(t_lines_u) if t_lines_u else "—") + \
                    "\nValue (Top10):\n" + ("\n".join(t_lines_v) if t_lines_v else "—")
            blocks.append(block)
            figs_u.append(pie_chart(f"Company Share in ATC {level} {cl} (Units, {last_year})",
                                    labels=top10.index.tolist(), values=top10["Units"].tolist(), top_k=10))
            figs_v.append(pie_chart(f"Company Share in ATC {level} {cl} (Value, {last_year})",
                                    labels=top10.index.tolist(), values=top10["Value"].tolist(), top_k=10))
        return blocks, figs_u, figs_v

    _ensure_atc_levels(DF)
    blocks_L2, figs_L2_u, figs_L2_v = _company_atc_pies("L2")
    blocks_L3, figs_L3_u, figs_L3_v = _company_atc_pies("L3")

    # ===== Company peers (>=10% overlap)
    peers, base_set = _company_peer_overlap(DF, company_name, thr=0.10)
    peers_names = [p[0] for p in peers]
    peers_text = "—" if not peers else "\n".join([f"- {fa_display(nm)} — overlap {ov*100:.1f}%" for nm,ov in peers[:20]])

    pie_peers_units = None
    pie_peers_value = None
    ms_peers_units = 0.0
    ms_peers_value = 0.0
    if peers_names:
        group = DF[(DF["Year"]==last_year) & (DF["Licensee"].isin(peers_names + [sub["Licensee"].iloc[0]]))]
        g = group.groupby("Licensee")[["Units","Value"]].sum()
        g = g.sort_values("Value", ascending=False) if g["Value"].sum()>0 else g.sort_values("Units", ascending=False)
        TOP_N = 10
        g_top = g.head(TOP_N)
        tot_u = float(g["Units"].sum())
        tot_v = float(g["Value"].sum())
        my_u = float(g.loc[g.index.map(lambda s: normalize_fa(s).lower()==n), "Units"].sum()) if not g.empty else 0.0
        my_v = float(g.loc[g.index.map(lambda s: normalize_fa(s).lower()==n), "Value"].sum()) if not g.empty else 0.0
        ms_peers_units = (my_u/tot_u*100) if tot_u>0 else 0.0
        ms_peers_value = (my_v/tot_v*100) if tot_v>0 else 0.0
        pie_peers_units = pie_chart(f"Peer-Set Share (Units, {last_year}) — {company_name}",
                                    labels=g_top.index.tolist(), values=g_top["Units"].tolist(), top_k=TOP_N)
        pie_peers_value = pie_chart(f"Peer-Set Share (Value, {last_year}) — {company_name}",
                                    labels=g_top.index.tolist(), values=g_top["Value"].tolist(), top_k=TOP_N)

    # AI brief (single call)
    table_txt = "Year,Units,Value,AvgPrice\n" + "\n".join(
        [f"{int(i)},{float(r['Units']):.6f},{float(r['Value']):.6f},{float(r['Avg Price']):.6f}"
         for i,r in y[["Units","Value","Avg Price"]].iterrows()]
    )
    prompt = f"""Company analytic brief for '{company_name}'.
Include: portfolio mix (top generics), pricing, growth, risk, 5y outlook; end with 3 actionable suggestions.
TABLE:
{table_txt}
Top-5 Generics (Units):
{top5_text}
Forms:
{form_text}
Total market share last year: Units {ms_total_units:.2f}%, Value {ms_total_value:.2f}%.
"""
    ai_block = ai_analyze("Company Brief", prompt)

    # Figures
    figs = [
        smart_plot(f"Unit Sales — {company_name}", y.index, y["Units"], "Units"),
        smart_plot(f"Value Sales — {company_name}", y.index, y["Value"], "Value"),
        smart_plot(f"Average Price — {company_name}", y.index, y["Avg Price"], "Average Price"),
        smart_plot(f"YoY Unit Growth — {company_name}", y.index, y["YoY Units %"], "YoY %"),
        smart_plot(f"Forecast Units (5y) — {company_name}", fc_units.index, fc_units, "Units (fc)"),
        smart_plot(f"Forecast Value (5y) — {company_name}", fc_value.index, fc_value, "Value (fc)"),
        smart_plot(f"Forecast Price (5y) — {company_name}", fc_price.index, fc_price, "Avg Price (fc)"),
        fig_pie_total_units, fig_pie_total_value
    ]
    figs.extend(figs_L2_u); figs.extend(figs_L2_v)
    figs.extend(figs_L3_u); figs.extend(figs_L3_v)
    if pie_peers_units is not None: figs.append(pie_peers_units)
    if pie_peers_value is not None: figs.append(pie_peers_value)

    # Text
    y_lines = ["Year | Units | Value | Avg Price | YoY Units% | YoY Value%"]
    for yr, row in y.iterrows():
        y_lines.append(f"{yr} | {fmt_int(row['Units'])} | {fmt_int(row['Value'])} | {fmt_int(row['Avg Price'])} | {row['YoY Units %']:.1f}% | {row['YoY Value %']:.1f}%")

    text = f"""
COMPANY ANALYSIS — {fa_display(company_name)}

SUMMARY
- Total Units: {fmt_int(total_units)} | Total Value: {fmt_int(total_value)}
- CAGR — Units: {units_cagr:.2%} | Value: {value_cagr:.2%}
- Total Market Share ({last_year}): Units {fmt_pct4(ms_total_units)} | Value {fmt_pct4(ms_total_value)}

YEARLY BREAKDOWN
{chr(10).join(y_lines)}

5-YEAR FORECAST (formula)
Year | Units (fc) | Value (fc) | Price (fc)
{chr(10).join([f"{yr} | {fmt_int(fc_units.loc[yr])} | {fmt_int(fc_value.loc[yr])} | {fmt_int(fc_price.loc[yr])}" for yr in fc_units.index])}

TOP-5 GENERICS (Units)
{top5_text}

DOSAGE FORMS
{form_text}

ATC LEVEL-2 CLUSTERS — last year (Top10 share lists per cluster)
{chr(10).join(blocks_L2) if blocks_L2 else '—'}

ATC LEVEL-3 CLUSTERS — last year (Top10 share lists per cluster)
{chr(10).join(blocks_L3) if blocks_L3 else '—'}

PEERS (≥10% portfolio overlap on Generic Names)
{peers_text}
- Peer-set Market Share ({last_year}): Units {fmt_pct4(ms_peers_units)} | Value {fmt_pct4(ms_peers_value)}

AI INSIGHT (single call)
{ai_block}
""".strip()
    return text, figs
def _forms_distribution_series(df_sub):
    """
    df_sub: DataFrame شامل ردیف‌های مربوط به Sub-Products یک دارو یا یک شرکت
            که ستون Dosage Form در آن موجود است.

    خروجی: Series شامل درصد سهم هر Dosage Form از کل Value
    """

    if df_sub is None or len(df_sub) == 0:
        return pd.Series(dtype=float)

    # اگر ستون وجود ندارد
    if "Dosage Form" not in df_sub.columns or "Value" not in df_sub.columns:
        return pd.Series(dtype=float)

    # حذف مقادیر خالی
    tmp = df_sub[["Dosage Form", "Value"]].dropna()
    if len(tmp) == 0:
        return pd.Series(dtype=float)

    # گروه‌بندی
    s = tmp.groupby("Dosage Form")["Value"].sum()

    total = s.sum()
    if total == 0:
        return pd.Series(dtype=float)

    # تبدیل به درصد
    return s * 100 / total

def _forms_distribution_series(df_sub):
    if df_sub is None or len(df_sub) == 0:
        return pd.Series(dtype=float)

    if "Dosage Form" not in df_sub.columns or "Value" not in df_sub.columns:
        return pd.Series(dtype=float)

    tmp = df_sub[["Dosage Form", "Value"]].dropna()
    if len(tmp) == 0:
        return pd.Series(dtype=float)

    s = tmp.groupby("Dosage Form")["Value"].sum()
    total = s.sum()
    if total == 0:
        return pd.Series(dtype=float)

    return s * 100 / total

def _forms_distribution_series(df_sub):
    if df_sub is None or len(df_sub) == 0:
        return pd.Series(dtype=float)

    # ایمن‌سازی برای وجود ستون‌ها
    if "Dosage Form" not in df_sub.columns or "Value" not in df_sub.columns:
        return pd.Series(dtype=float)

    tmp = df_sub[["Dosage Form", "Value"]].dropna()
    if len(tmp) == 0:
        return pd.Series(dtype=float)

    s = tmp.groupby("Dosage Form")["Value"].sum()
    total = s.sum()
    if total == 0:
        return pd.Series(dtype=float)

    return s * 100 / total

def _top_sub_analysis(S):
    sub = S["sub"].copy()
    if len(sub) == 0:
        return "No Sub-Products.\n"

    sub = sub.sort_values("Value", ascending=False)
    top = sub.head(3)

    txt = ""
    for _, r in top.iterrows():
        name = fa_display(r.get("Name", "—"))
        val = fmt_int(r.get("Value", 0))
        yoy = r.get("YoY Value %", 0)
        txt += f"- {name}: {val}  (YoY {yoy:.1%})\n"
    return txt

def _safe_get_hhi(S):
    c = S.get("concentration", {})
    # نام‌های احتمالی
    for key in ["ATC3_HHI", "ATC3_HHI_Value", "ATC3_HHI_Units", "ATC-L3 HHI", "ATC3HHI"]:
        if key in c:
            return c[key]
    # اگر هیچ کدام نبود → صفر
    return 0

import matplotlib.pyplot as plt

def compare_drugs(drug1: str, drug2: str):
    """
    Head-to-head comparison of two active ingredients based on DF.

    Returns:
        text (str): English narrative report
        figs (list[matplotlib.figure.Figure]): comparison charts
    """
    DF, _ = get_data()

    ins1 = compute_drug_insights(drug1)
    ins2 = compute_drug_insights(drug2)

    if ins1.get("empty"):
        return f"❌ No data for '{drug1}'. Try exact ING1/2/3 or Generic Name.", []
    if ins2.get("empty"):
        return f"❌ No data for '{drug2}'. Try exact ING1/2/3 or Generic Name.", []

    y1, y2 = ins1["yearly"], ins2["yearly"]
    last_year = max(int(y1.index.max()), int(y2.index.max()))

    # ---------- 1) Key metrics table (with thousand separators) ----------
    rows = [
        ("Total Units",
         fmt_int(ins1["total_units"]),
         fmt_int(ins2["total_units"]), ""),

        ("Total Value",
         fmt_int(ins1["total_value"]),
         fmt_int(ins2["total_value"]), ""),

        ("Avg Price",
         fmt_int(ins1["avg_price"]),
         fmt_int(ins2["avg_price"]), ""),

        ("Units CAGR",
         f"{ins1['units_cagr']:.2%}",
         f"{ins2['units_cagr']:.2%}", ""),

        ("Value CAGR",
         f"{ins1['value_cagr']:.2%}",
         f"{ins2['value_cagr']:.2%}", ""),

        (f"MS Total Units {last_year}",
         f"{ins1['ms_total_units']:.1f}%",
         f"{ins2['ms_total_units']:.1f}%", ""),

        (f"MS Total Value {last_year}",
         f"{ins1['ms_total_value']:.1f}%",
         f"{ins2['ms_total_value']:.1f}%", ""),

        ("Concentration (HHI label)",
         ins1["concentration"]["label"],
         ins2["concentration"]["label"], ""),
    ]
    kv_table = _fmt_kv_table(rows)

    # ---------- 2) Dual line charts ----------
    figs = [
        plot_dual_series(
            f"Units — {drug1} vs {drug2}",
            y1.index.tolist(), y1["Units"],
            y2.index.tolist(), y2["Units"],
            drug1, drug2, "Units"
        ),
        plot_dual_series(
            f"Value — {drug1} vs {drug2}",
            y1.index.tolist(), y1["Value"],
            y2.index.tolist(), y2["Value"],
            drug1, drug2, "Value"
        ),
        plot_dual_series(
            f"Average Price — {drug1} vs {drug2}",
            y1.index.tolist(), y1["Avg Price"],
            y2.index.tolist(), y2["Avg Price"],
            drug1, drug2, "Avg Price"
        ),
        plot_dual_series(
            f"YoY Units % — {drug1} vs {drug2}",
            y1.index.tolist(), y1["YoY Units %"],
            y2.index.tolist(), y2["YoY Units %"],
            drug1, drug2, "YoY %"
        ),
    ]

    # ---------- 3) Leader companies & dosage forms (plain English blocks) ----------
    leaders1 = ins1.get("leader_co_ing_text", "") or "—"
    leaders2 = ins2.get("leader_co_ing_text", "") or "—"
    forms1   = ins1.get("form_text", "") or "—"
    forms2   = ins2.get("form_text", "") or "—"
    combos1  = ins1.get("combo_text", "") or "—"
    combos2  = ins2.get("combo_text", "") or "—"

    # ---------- 4) AI narrative (English) ----------
    ai_text = ai_analyze(
        "Drug head-to-head comparison",
        (
            f"Compare the two active ingredients '{drug1}' and '{drug2}' using the following facts:\n"
            f"- Total units: {fmt_int(ins1['total_units'])} vs {fmt_int(ins2['total_units'])}\n"
            f"- Total value: {fmt_int(ins1['total_value'])} vs {fmt_int(ins2['total_value'])}\n"
            f"- CAGR (value): {ins1['value_cagr']:.2%} vs {ins2['value_cagr']:.2%}\n"
            f"- Market share (value, {last_year}): {ins1['ms_total_value']:.1f}% vs {ins2['ms_total_value']:.1f}%\n"
            "Write a concise, investor-style comparison: who leads today, trend strength, "
            "substitution risk, and 5‑year outlook."
        )
    )

    # ---------- 5) Final text report ----------
    text = f"""
DRUG HEAD-TO-HEAD — {drug1} vs {drug2}

{kv_table}

LEADING COMPANIES (by Units) — {drug1}

{leaders1}

LEADING COMPANIES (by Units) — {drug2}

{leaders2}

MAIN DOSAGE FORMS — {drug1}

{forms1}

MAIN DOSAGE FORMS — {drug2}

{forms2}

KEY COMBINATIONS — {drug1}

{combos1}

KEY COMBINATIONS — {drug2}

{combos2}

AI NARRATIVE (ENGLISH)

{ai_text}
""".strip()

    return text, figs

def compare_companies(co1: str, co2: str):
    """
    Head-to-head comparison of two companies (Licensees) based on DF.

    Returns:
        text (str): English narrative report
        figs (list[matplotlib.figure.Figure]): comparison charts
    """
    ins1 = compute_company_insights(co1)
    ins2 = compute_company_insights(co2)

    if ins1.get("empty"):
        return f"❌ No data for '{co1}'.", []
    if ins2.get("empty"):
        return f"❌ No data for '{co2}'.", []

    y1, y2 = ins1["yearly"], ins2["yearly"]
    last_year = max(int(y1.index.max()), int(y2.index.max()))

    # ---------- 1) Overlap of top generics ----------
    def _extract_gens(top_text: str):
        gens = set()
        for line in (top_text or "").splitlines():
            if "%" not in line:
                continue
            # pattern: "- Generic: 123 (12.3%)"
            name = line.split(":")[0].replace("-", "").strip()
            if name:
                gens.add(name)
        return gens

    g1 = _extract_gens(ins1.get("top_generics_text", ""))
    g2 = _extract_gens(ins2.get("top_generics_text", ""))
    overlap = sorted(g1 & g2)
    overlap_pct = (len(overlap) / min(len(g1), len(g2)) * 100) if g1 and g2 else 0.0
    overlap_text = "\n".join(f"- {g}" for g in overlap) if overlap else "None"

    # ---------- 2) Key metrics table ----------
    rows = [
        ("Total Units",
         fmt_int(ins1["total_units"]),
         fmt_int(ins2["total_units"]), ""),

        ("Total Value",
         fmt_int(ins1["total_value"]),
         fmt_int(ins2["total_value"]), ""),

        ("Avg Price",
         fmt_int(ins1["avg_price"]),
         fmt_int(ins2["avg_price"]), ""),

        ("Units CAGR",
         f"{ins1['units_cagr']:.2%}",
         f"{ins2['units_cagr']:.2%}", ""),

        ("Value CAGR",
         f"{ins1['value_cagr']:.2%}",
         f"{ins2['value_cagr']:.2%}", ""),

        (f"MS Total Units {last_year}",
         f"{ins1['ms_total_units']:.1f}%",
         f"{ins2['ms_total_units']:.1f}%", ""),

        (f"MS Total Value {last_year}",
         f"{ins1['ms_total_value']:.1f}%",
         f"{ins2['ms_total_value']:.1f}%", ""),

        ("Concentration (HHI label)",
         ins1["concentration"]["label"],
         ins2["concentration"]["label"], ""),

        ("Overlap Generics",
         f"{len(overlap)} ({overlap_pct:.0f}%)",
         "", ""),
    ]
    kv_table = _fmt_kv_table(rows)

    # ---------- 3) Charts (same size for both companies) ----------
    figs = [
        # Head-to-head overlays
        plot_dual_series(
            f"Units — {co1} vs {co2}",
            y1.index.tolist(), y1["Units"],
            y2.index.tolist(), y2["Units"],
            co1, co2, "Units"
        ),
        plot_dual_series(
            f"Value — {co1} vs {co2}",
            y1.index.tolist(), y1["Value"],
            y2.index.tolist(), y2["Value"],
            co1, co2, "Value"
        ),
        plot_dual_series(
            f"Average Price — {co1} vs {co2}",
            y1.index.tolist(), y1["Avg Price"],
            y2.index.tolist(), y2["Avg Price"],
            co1, co2, "Avg Price"
        ),
        plot_dual_series(
            f"YoY Units % — {co1} vs {co2}",
            y1.index.tolist(), y1["YoY Units %"],
            y2.index.tolist(), y2["YoY Units %"],
            co1, co2, "YoY %"
        ),

        # Standalone time-series for each company (same figsize via smart_plot)
        smart_plot(f"{co1} — Units over time",      y1.index.tolist(), y1["Units"],     "Units"),
        smart_plot(f"{co1} — Value over time",      y1.index.tolist(), y1["Value"],     "Value"),
        smart_plot(f"{co1} — Avg Price over time",  y1.index.tolist(), y1["Avg Price"], "Avg Price"),

        smart_plot(f"{co2} — Units over time",      y2.index.tolist(), y2["Units"],     "Units"),
        smart_plot(f"{co2} — Value over time",      y2.index.tolist(), y2["Value"],     "Value"),
        smart_plot(f"{co2} — Avg Price over time",  y2.index.tolist(), y2["Avg Price"], "Avg Price"),

        # Market share and concentration pies (same construction)
        ins1.get("fig_ms_units"),
        ins1.get("fig_ms_value"),
        ins1.get("fig_top_generics"),
        ins1.get("fig_concentration"),
        ins2.get("fig_ms_units"),
        ins2.get("fig_ms_value"),
        ins2.get("fig_top_generics"),
        ins2.get("fig_concentration"),
    ]
    figs = [f for f in figs if f is not None]

    # ---------- 4) Text blocks ----------
    top_g1 = ins1.get("top_generics_text", "") or "—"
    top_g2 = ins2.get("top_generics_text", "") or "—"
    top_b1 = ins1.get("top_brands_text", "") or "—"
    top_b2 = ins2.get("top_brands_text", "") or "—"
    form1  = ins1.get("form_text", "") or "—"
    form2  = ins2.get("form_text", "") or "—"
    combo1 = ins1.get("combo_text", "") or "—"
    combo2 = ins2.get("combo_text", "") or "—"
    atc1   = ins1.get("top_atc_text", "") or "—"
    atc2   = ins2.get("top_atc_text", "") or "—"
    peers1 = ins1.get("peers_text", "") or "—"
    peers2 = ins2.get("peers_text", "") or "—"

    # ---------- 5) AI narrative (English) ----------
    ai_text = ai_analyze(
        "Company head-to-head comparison",
        (
            f"Compare the two companies '{co1}' and '{co2}' as pharma licensees using these facts:\n"
            f"- Total value: {fmt_int(ins1['total_value'])} vs {fmt_int(ins2['total_value'])}\n"
            f"- CAGR (value): {ins1['value_cagr']:.2%} vs {ins2['value_cagr']:.2%}\n"
            f"- Market share (value, {last_year}): "
            f"{ins1['ms_total_value']:.1f}% vs {ins2['ms_total_value']:.1f}%\n"
            f"- Portfolio concentration: {ins1['concentration']['label']} vs "
            f"{ins2['concentration']['label']}\n"
            f"- Overlapping key generics: {len(overlap)}.\n"
            "Write a concise, investor-style comparison: portfolio positioning, "
            "growth profile, competitive risk, and 5‑year strategic outlook."
        )
    )

    # ---------- 6) Final English text report ----------
    text = f"""
COMPANY HEAD-TO-HEAD — {co1} vs {co2}

{kv_table}

TOP GENERICS (by Units) — {co1}

{top_g1}

TOP GENERICS (by Units) — {co2}

{top_g2}

TOP BRANDS (by Units) — {co1}

{top_b1}

TOP BRANDS (by Units) — {co2}

{top_b2}

DOSAGE FORMS — {co1}

{form1}

DOSAGE FORMS — {co2}

{form2}

KEY COMBINATIONS — {co1}

{combo1}

KEY COMBINATIONS — {co2}

{combo2}

TOP ATC L3 CLASSES — {co1}

{atc1}

TOP ATC L3 CLASSES — {co2}

{atc2}

ATC PEERS (MAIN RIVALS) — {co1}

{peers1}

ATC PEERS (MAIN RIVALS) — {co2}

{peers2}

OVERLAP IN KEY GENERICS

{overlap_text}

AI NARRATIVE (ENGLISH)

{ai_text}
""".strip()

    return text, figs

def _company_metrics_for_h2h(company_name: str):
    """
    This function takes a company name and retrieves relevant metrics for the head-to-head comparison.
    The data source might be a DataFrame, database, or any other structure depending on your app's setup.
    """
    # فرض می‌کنیم که داده‌ها به صورت یک دیکشنری هستند. این باید با سیستم داده واقعی شما تطابق داشته باشد.
    company_data = {
        "CompanyA": {
            "total_units": 500000,
            "total_value": 2000000,
            "units_cagr": 0.05,
            "value_cagr": 0.06,
            "ms_unit": 35.5,
            "ms_value": 40.2,
            "last_avg_price": 10.0,
            "top5_products": ["Product A1", "Product A2", "Product A3", "Product A4", "Product A5"],
            "sub": {"form_1": 60, "form_2": 40},  # Example Dosage Form distribution
            "y": pd.DataFrame({
                "Units": [5000, 5100, 5200, 5300],
                "Value": [20000, 20500, 21000, 21500],
                "Avg Price": [10, 10.1, 10.2, 10.3],
            }),
            "fc_units": pd.Series([5400, 5500, 5600, 5700], index=pd.date_range("2024-01-01", periods=4, freq="Y")),
        },
        "CompanyB": {
            "total_units": 400000,
            "total_value": 1500000,
            "units_cagr": 0.04,
            "value_cagr": 0.05,
            "ms_unit": 30.2,
            "ms_value": 35.1,
            "last_avg_price": 12.0,
            "top5_products": ["Product B1", "Product B2", "Product B3", "Product B4", "Product B5"],
            "sub": {"form_1": 50, "form_2": 50},  # Example Dosage Form distribution
            "y": pd.DataFrame({
                "Units": [4000, 4100, 4200, 4300],
                "Value": [16000, 16500, 17000, 17500],
                "Avg Price": [12, 12.1, 12.2, 12.3],
            }),
            "fc_units": pd.Series([4400, 4500, 4600, 4700], index=pd.date_range("2024-01-01", periods=4, freq="Y")),
        },
    }

    # داده‌ها را برای شرکت مورد نظر برمی‌گرداند
    return company_data.get(company_name, None)
  
def _forecast_series(series, periods=12):
    """
    Simple linear regression forecast for monthly or yearly sales.
    Works with very small datasets too.
    """
    import numpy as np
    import pandas as pd
    from sklearn.linear_model import LinearRegression

    s = series.dropna()
    if len(s) < 2:
        # Not enough data
        idx = pd.RangeIndex(len(s), len(s) + periods)
        return pd.Series([s.iloc[-1]] * periods, index=idx)

    X = np.arange(len(s)).reshape(-1, 1)
    y = s.values

    model = LinearRegression()
    model.fit(X, y)

    future_X = np.arange(len(s), len(s) + periods).reshape(-1, 1)
    forecast = model.predict(future_X)

    # Future index
    last_idx = s.index[-1]
    if isinstance(last_idx, int):
        future_idx = [last_idx + i + 1 for i in range(periods)]
    else:
        future_idx = pd.date_range(last_idx, periods=periods+1, freq="Y")[1:]

    return pd.Series(forecast, index=future_idx)

# --------------- Top-N Reports (Companies/Drugs/Brands by Units/Value)
def _resolve_year(year):
    DF, _ = get_data()
    if year is None or str(year).strip().lower() in {"", "last", "latest"}:
        return int(DF["Year"].max())
    try:
        return int(str(year).strip())
    except:
        return int(DF["Year"].max())

def top_companies_by_value(n="5", year=None):
    DF, _ = get_data()
    try: n = int(str(n).strip())
    except: n = 5
    year = _resolve_year(year)
    sub = DF[DF["Year"] == year]
    if sub.empty:
        return f"❌ No data for year {year}.", []
    g = sub.groupby("Licensee")[["Value","Units"]].sum().sort_values("Value", ascending=False)
    top = g.head(n)
    tot_v = float(g["Value"].sum()) if not g.empty else 0.0
    lines = [f"TOP {n} COMPANIES — Value — Year {year}"]
    rank = 1
    for lic, row in top.iterrows():
        share = (float(row["Value"])/tot_v*100) if tot_v>0 else 0.0
        lines.append(f"{rank}. {fa_display(lic)} — Value {fmt_int(row['Value'])} ({share:.1f}%)  | Units {fmt_int(row['Units'])}")
        rank += 1
    figs = [
        bar_chart_top(f"Top {n} Companies by Value — {year}", labels=top.index.tolist(), values=top["Value"].tolist()),
        pie_chart(f"Top {n} Companies Share (Value) — {year}", labels=top.index.tolist(), values=top["Value"].tolist(), top_k=n)
    ]
    return "\n".join(lines), figs

def top_companies_by_units(n="5", year=None):
    DF, _ = get_data()
    try: n = int(str(n).strip())
    except: n = 5
    year = _resolve_year(year)
    sub = DF[DF["Year"] == year]
    if sub.empty:
        return f"❌ No data for year {year}.", []
    g = sub.groupby("Licensee")[["Units","Value"]].sum().sort_values("Units", ascending=False)
    top = g.head(n)
    tot_u = float(g["Units"].sum()) if not g.empty else 0.0
    lines = [f"TOP {n} COMPANIES — Units — Year {year}"]
    rank = 1
    for lic, row in top.iterrows():
        share = (float(row["Units"])/tot_u*100) if tot_u>0 else 0.0
        lines.append(f"{rank}. {fa_display(lic)} — Units {fmt_int(row['Units'])} ({share:.1f}%)  | Value {fmt_int(row['Value'])}")
        rank += 1
    figs = [
        bar_chart_top(f"Top {n} Companies by Units — {year}", labels=top.index.tolist(), values=top["Units"].tolist()),
        pie_chart(f"Top {n} Companies Share (Units) — {year}", labels=top.index.tolist(), values=top["Units"].tolist(), top_k=n)
    ]
    return "\n".join(lines), figs

def top_brands_by_units(n="10", year=None):
    DF, _ = get_data()
    try: n = int(str(n).strip())
    except: n = 10
    year = _resolve_year(year)
    sub = DF[DF["Year"] == year]
    if sub.empty:
        return f"❌ No data for year {year}.", []
    if "Brand Name" not in DF.columns or not DF["Brand Name"].astype(str).str.strip().any():
        return "⚠️ Brand Name column not found in dataset.", []
    g = sub.groupby("Brand Name")[["Units","Value"]].sum().sort_values("Units", ascending=False)
    top = g.head(n)
    tot_u = float(g["Units"].sum()) if not g.empty else 0.0
    lines = [f"TOP {n} BRANDS — Units — Year {year}"]
    rank = 1
    for name, row in top.iterrows():
        share = (float(row["Units"])/tot_u*100) if tot_u>0 else 0.0
        lines.append(f"{rank}. {fa_display(name)} — Units {fmt_int(row['Units'])} ({share:.1f}%)  | Value {fmt_int(row['Value'])}")
        rank += 1
    figs = [
        bar_chart_top(f"Top {n} Brands by Units — {year}", labels=top.index.tolist(), values=top["Units"].tolist()),
        pie_chart(f"Top {n} Brands Share (Units) — {year}", labels=top.index.tolist(), values=top["Units"].tolist(), top_k=n)
    ]
    return "\n".join(lines), figs

def top_drugs_by_units(n="5", year=None):
    DF, _ = get_data()
    try: n = int(str(n).strip())
    except: n = 5
    year = _resolve_year(year)
    sub = DF[DF["Year"] == year]
    if sub.empty:
        return f"❌ No data for year {year}.", []
    g = sub.groupby("Generic Name")[["Units","Value"]].sum().sort_values("Units", ascending=False)
    top = g.head(n)
    tot_u = float(g["Units"].sum()) if not g.empty else 0.0
    lines = [f"TOP {n} DRUGS — Units — Year {year}"]
    rank = 1
    for gen, row in top.iterrows():
        share = (float(row["Units"])/tot_u*100) if tot_u>0 else 0.0
        lines.append(f"{rank}. {fa_display(gen)} — Units {fmt_int(row['Units'])} ({share:.1f}%)  | Value {fmt_int(row['Value'])}")
        rank += 1
    figs = [
        bar_chart_top(f"Top {n} Drugs by Units — {year}", labels=top.index.tolist(), values=top["Units"].tolist()),
        pie_chart(f"Top {n} Drugs Share (Units) — {year}", labels=top.index.tolist(), values=top["Units"].tolist(), top_k=n)
    ]
    return "\n".join(lines), figs

def top_drugs_by_value(n="5", year=None):
    DF, _ = get_data()
    try: n = int(str(n).strip())
    except: n = 5
    year = _resolve_year(year)
    sub = DF[DF["Year"] == year]
    if sub.empty:
        return f"❌ No data for year {year}.", []
    g = sub.groupby("Generic Name")[["Value","Units"]].sum().sort_values("Value", ascending=False)
    top = g.head(n)
    tot_v = float(g["Value"].sum()) if not g.empty else 0.0
    lines = [f"TOP {n} DRUGS — Value — Year {year}"]
    rank = 1
    for gen, row in top.iterrows():
        share = (float(row["Value"])/tot_v*100) if tot_v>0 else 0.0
        lines.append(f"{rank}. {fa_display(gen)} — Value {fmt_int(row['Value'])} ({share:.1f}%)  | Units {fmt_int(row['Units'])}")
        rank += 1
    figs = [
        bar_chart_top(f"Top {n} Drugs by Value — {year}", labels=top.index.tolist(), values=top["Value"].tolist()),
        pie_chart(f"Top {n} Drugs Share (Value) — {year}", labels=top.index.tolist(), values=top["Value"].tolist(), top_k=n)
    ]
    return "\n".join(lines), figs

# --------------- Disease
def disease_analysis(disease_fa: str):
    disease_en = translate_fa_to_en(disease_fa) or disease_fa
    prompt = f"""Write an English clinical brief for "{disease_en}" with:
1) concise definition, causes/risk factors, key symptoms & diagnostics;
2) pharmacologic therapy by line (first/second/adjunct), key drug classes & example drugs, notable doses/monitoring;
3) list ALL relevant drugs as bullets: Drug — Class — Note (First-line/Second-line/Adjunct/Prophylaxis/Special populations);
4) 3 red-flag notes and 3 follow-up tips.
Keep it concise and clinically correct."""
    return ai_analyze("Disease Brief", prompt)

# --------------- PDF Export
def export_report_to_pdf(filename: str, title: str, text_content: str, figs: list):
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.enums import TA_LEFT, TA_CENTER
        from reportlab.lib.units import cm
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, PageBreak, KeepTogether
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont
        from matplotlib import font_manager
        base_font = "Helvetica"
        try:
            dv = font_manager.findfont("DejaVu Sans", fallback_to_default=True)
            if os.path.isfile(dv):
                pdfmetrics.registerFont(TTFont("DejaVuSans", dv)); base_font = "DejaVuSans"
        except Exception:
            pass
        def _prep_line(line: str) -> str:
            parts = [fa_display(seg) for seg in line.split(" ")]
            return " ".join(parts)
        doc = SimpleDocTemplate(filename, pagesize=A4, leftMargin=2*cm, rightMargin=2*cm, topMargin=1.8*cm, bottomMargin=1.5*cm)
        styles = getSampleStyleSheet()
        styles.add(ParagraphStyle(name="TitleZ", parent=styles["Title"], fontName=base_font, fontSize=18, leading=22, alignment=TA_CENTER))
        styles.add(ParagraphStyle(name="BodyZ", parent=styles["BodyText"], fontName=base_font, fontSize=10.8, leading=15, alignment=TA_LEFT))
        flow = [Paragraph(title, styles["TitleZ"]), Spacer(1, 0.4*cm)]
        for line in (text_content or "").split("\n"):
            flow.append(Spacer(1, 0.12*cm) if line.strip()=="" else Paragraph(_prep_line(line).replace("  ","&nbsp;&nbsp;"), styles["BodyZ"]))
        if figs:
            flow.append(PageBreak())
            for i, fig in enumerate(figs, 1):
                buf = io.BytesIO(); fig.savefig(buf, format="png", dpi=180, bbox_inches="tight"); buf.seek(0)
                img = Image(buf, width=16.5*cm, height=None)
                flow.append(KeepTogether([Paragraph(f"Figure {i}", styles["BodyZ"]), Spacer(1, 0.2*cm), img]))
                if i < len(figs): flow.append(PageBreak())
        doc.build(flow); return True, None
    except Exception as e:
        return False, str(e)

# --------------- Plot Host (simple GUI)
def _safe_update_text(self, text_widget, new_text):
    """ایمن insert/delete با chunking و RTL fix"""
    try:
        text_widget.delete("1.0", tk.END)
        # chunk برای متن طولانی
        for chunk in (new_text or "").splitlines(keepends=True):
            chunk = fa_display(chunk)  # RTL fix
            text_widget.insert(tk.END, chunk)
        text_widget.see(tk.END)  # scroll to end
    except tk.TclError:
        text_widget.delete("1.0", tk.END)
        text_widget.insert("1.0", f"[Error displaying: len={len(new_text or '')}]\n{str(new_text)[:500]}...")

class PlotHost:
    def __init__(self, parent_frame):
        self.parent = parent_frame
        self.canvases, self._figs = [], []
        self.canvas = tk.Canvas(parent_frame, highlightthickness=0)
        self.scrollbar = ttk.Scrollbar(parent_frame, orient="vertical", command=self.canvas.yview)
        self.inner = ttk.Frame(self.canvas)
        self.inner.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.create_window((0,0), window=self.inner, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    def clear(self):
        for c in self.canvases:
            try: c.get_tk_widget().destroy()
            except: pass
        for f in self._figs:
            try: plt.close(f)
            except: pass
        self.canvases, self._figs = [], []
    def show_figs(self, figs):
        self.clear()
        for fig in figs:
            fig.set_size_inches(7.6, 3.6)
            canvas = FigureCanvasTkAgg(fig, master=self.inner)
            canvas.draw()
            w = canvas.get_tk_widget()
            w.pack(side=tk.TOP, fill=tk.X, expand=False, padx=6, pady=8)
            self.canvases.append(canvas)
            self._figs.append(fig)

# --------------- TOP-query parser (FA/EN)
def parse_top_query(q_text: str):
    """
    Parse 'top ...' style queries (FA/EN) and return: (entity, metric, n, year)
    entity ∈ {'drug','company','brand', None}
    metric ∈ {'units','value'}
    """
    q = normalize_fa(q_text).lower()
    metric = 'value' if any(k in q for k in ['value','ارزش','ریالی','consumervalue','consumerprice']) else 'units'
    n = extract_n_from_text(q_text, default=10)
    year = extract_year_from_text(q_text, default=None)
    if any(k in q for k in ['مادهموثره','ماده موثره','ژنریک','generic','ingredient','drug']):
        entity = 'drug'
    elif any(k in q for k in ['شرکت','licensee','company']):
        entity = 'company'
    elif any(k in q for k in ['برند','نامتجاری','نام تجاری','brand']):
        entity = 'brand'
    else:
        if 'top' in q or 'پرفروش' in q or 'ترین' in q or 'ترین‌ها' in q:
            entity = 'drug'
        else:
            entity = None
    return entity, metric, n, year

def _detect_h2h_pairs(text: str):
    # خروجی: (left, right) اگر دو نام قابل تشخیص باشد؛ وگرنه (None, None)
    t = normalize_fa(text).lower()
    # جداکننده‌های رایج
    seps = [r"\s+vs\s+", r"\s+v\s+\.\s*", r"\s+در\s+مقابل\s+", r"\s+برابر\s+", r"\s+در\s+برابر\s+", r"\s+و\s+", r"\s*,\s*"]
    for sp in seps:
        m = re.split(sp, t)
        if len(m) == 2 and all(len(x.strip())>=2 for x in m):
            return m[0].strip(), m[1].strip()
    # حالت‌های «… را با … مقایسه کن»
    m = re.search(r"مقایسه\s+(.*?)\s+با\s+(.*)", t)
    if m:
        a, b = m.group(1).strip(), m.group(2).strip()
        if a and b and a != b:
            return a, b
    return None, None

def _guess_entity_type_for_h2h(text: str):
    q = normalize_fa(text).lower()
    if any(k in q for k in ['شرکت','licensee','company']):
        return "company"
    if any(k in q for k in ['برند','نام تجاری','brand']):
        return "brand"
    # پیش‌فرض دارو/ماده موثره
    return "drug"

# --------------- LLM Router ---------------
def llm_router(question: str):
    """Route a free-form question to the right analytic function (H2H-first)."""

    # 0) اگر Head-to-Head مشخص باشد، مستقیماً هدایت کن
    L, R = _detect_h2h_pairs(question)
    if L and R:
        ent = _guess_entity_type_for_h2h(question)
        if ent == "company":
            return {"function":"compare_companies", "args":[L, R]}
        elif ent == "brand":
            # برای برند در این نسخه، از compare_drugs استفاده می‌کنیم تا پوشش سریع بدهد
            return {"function":"compare_drugs", "args":[f"{L},{R}"]}
        else:
            return {"function":"compare_drugs", "args":[f"{L},{R}"]}

    # 1) First try rule-based entity detection (company/ingredient/brand)
    ent_route = detect_entity_and_route(question)
    if ent_route:
        return ent_route

    # 2) Fallback: LLM-based strict JSON router
    router_prompt = f"""
You are a strict router. Read the user's question and pick ONE function below.
If the question requires code/calculation, you MUST run the reasoning internally and return ONLY the final textual/numeric result — NEVER show code.
Functions and expected args:
1) summarize_drug(drug_name)
2) analyze_company(company_name)
3) compare_drugs("drug1,drug2")
4) compare_companies("company1","company2")
5) disease_analysis(disease_name)
6) top_companies_by_value(n, year_optional)
7) top_companies_by_units(n, year_optional)
8) top_drugs_by_units(n, year_optional)
9) top_drugs_by_value(n, year_optional)
10) ai_code_answer(question)

Extra rules:
- Prefer 'compare_*' if the question clearly asks to compare two named entities (detected by 'vs', 'and', 'و', 'در مقابل', 'مقایسه ... با ...').
- Default priority: active ingredient first, then brand.
- If the user mentions 'brand/برند/نام تجاری', prioritize brand.
Question: {{question}}
Rules:
- Return ONLY valid JSON with keys "function" and "args".
- "args" must be a JSON array of strings.
- Do NOT output code.
""".strip()

    out = ai_chat([
        {"role": "system", "content": "You are a strict function router. Output must be valid JSON only."},
        {"role": "user", "content": router_prompt.replace("{{question}}", question)},
    ])

    try:
        parsed = json.loads(out)
        if isinstance(parsed, dict) and "function" in parsed and "args" in parsed:
            return parsed
    except Exception:
        pass

    # 3) Last fallback
    return {"function": "ai_code_answer", "args": [question]}

# --------------- GUI

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Pharma Desk — Market Analytics (Modular Registry)")
        self.geometry("1280x900")
        try: self.call('tk','scaling',1.2)
        except Exception: pass

        nb = ttk.Notebook(self); nb.pack(fill=tk.BOTH, expand=True)
        self.tab_ask = ttk.Frame(nb)
        self.tab_drug = ttk.Frame(nb)
        self.tab_company = ttk.Frame(nb)
        self.tab_cmp_drugs = ttk.Frame(nb)
        self.tab_cmp_companies = ttk.Frame(nb)
        self.tab_disease = ttk.Frame(nb)
        self.tab_settings = ttk.Frame(nb)

        nb.add(self.tab_ask, text="Ask (LLM)")
        nb.add(self.tab_drug, text="Drug")
        nb.add(self.tab_company, text="Company")
        nb.add(self.tab_cmp_drugs, text="Compare Drugs")
        nb.add(self.tab_cmp_companies, text="Compare Companies")
        nb.add(self.tab_disease, text="Disease")
        nb.add(self.tab_settings, text="Settings")

        self.last_drug_text, self.last_drug_figs = "", []
        self.last_brand_text, self.last_brand_figs = "", []
        self.last_company_text, self.last_company_figs = "", []
        self.last_cmpd_text, self.last_cmpd_figs = "", []
        self.last_cmpc_text, self.last_cmpc_figs = "", []
        self.last_dis_text = ""

        self._build_tab_ask()
        self._build_tab_drug()
        self._build_tab_company()
        self._build_tab_cmp_drugs()
        self._build_tab_cmp_companies()
        self._build_tab_disease()
        self._build_tab_settings()

    def _make_io_area(self, parent, label_text, with_export=True):
        top = ttk.Frame(parent); top.pack(side=tk.TOP, fill=tk.X, padx=8, pady=6)
        label = ttk.Label(top, text=label_text); label.pack(side=tk.LEFT, padx=4)
        entry = ttk.Entry(top, width=60); entry.pack(side=tk.LEFT, padx=6)
        btn = ttk.Button(top, text="Run"); btn.pack(side=tk.LEFT, padx=6)
        export_btn = None
        if with_export:
            export_btn = ttk.Button(top, text="Save as PDF", state="disabled")
            export_btn.pack(side=tk.RIGHT, padx=6)
        mid = ttk.Frame(parent); mid.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        text = scrolledtext.ScrolledText(mid, height=18)
        text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(8,4), pady=(0,8))
        right = ttk.Frame(mid); right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(4,8), pady=(0,8))
        plot_host = PlotHost(right)
        return entry, btn, text, plot_host, export_btn

    # Ask (LLM)
    def _build_tab_ask(self):
        top = ttk.Frame(self.tab_ask); top.pack(side=tk.TOP, fill=tk.X, padx=8, pady=6)
        ttk.Label(top, text="Ask anything (drug/brand/company/compare/disease/top-n):").pack(side=tk.LEFT, padx=4)
        self.ask_entry = ttk.Entry(top, width=80); self.ask_entry.pack(side=tk.LEFT, padx=6)
        ttk.Button(top, text="Run", command=self._run_router).pack(side=tk.LEFT, padx=6)

        mid = ttk.Frame(self.tab_ask); mid.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        self.ask_text = scrolledtext.ScrolledText(mid, height=24)
        self.ask_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(8,4), pady=(0,8))

        self.ask_plot = PlotHost(mid)

    def _run_router(self):
        q = self.ask_entry.get().strip()
        if not q:
            messagebox.showinfo("Hint", "Enter a question.")
            return

        q_norm = normalize_fa(q).lower()
        if ('top' in q_norm) or ('پرفروش' in q_norm) or ('ترین' in q_norm) or ('ترین‌ها' in q_norm):
            entity, metric, n, year = parse_top_query(q)
            try:
                if entity == 'brand':
                    txt, figs = top_brands_by_units(str(n), year)
                elif entity == 'company':
                    if metric == 'value':
                        txt, figs = top_companies_by_value(str(n), year)
                    else:
                        txt, figs = top_companies_by_units(str(n), year)
                elif entity == 'drug':
                    if metric == 'value':
                        txt, figs = top_drugs_by_value(str(n), year)
                    else:
                        txt, figs = top_drugs_by_units(str(n), year)
                else:
                    txt, figs = top_drugs_by_units(str(n), year)

                self.ask_text.delete(1.0, tk.END); self.ask_text.insert(tk.END, txt)
                if isinstance(figs, list): self.ask_plot.show_figs(figs)
                return
            except Exception as e:
                self.ask_text.delete(1.0, tk.END)
                self.ask_text.insert(tk.END, f"Top Query Error: {e}")
                traceback.print_exc()
                return

        try:
            route = llm_router(q) or {}
            fn = route.get("function")
            args = route.get("args", [])
            txt, figs = "", []

            if fn == "summarize_drug":
                txt, figs = summarize_drug(*args)
            elif fn == "summarize_brand":
                txt, figs = summarize_brand(*args)
            elif fn == "analyze_company":
                txt, figs = analyze_company(*args)
            elif fn == "compare_drugs":
                txt, figs = compare_drugs(*args)
            elif fn == "compare_companies":
                txt, figs = compare_companies(*args)
            elif fn == "disease_analysis":
                txt = disease_analysis(*args)
            elif fn == "top_companies_by_value":
                if len(args) == 0: txt, figs = top_companies_by_value("5", None)
                elif len(args) == 1: txt, figs = top_companies_by_value(args[0], None)
                else: txt, figs = top_companies_by_value(args[0], args[1])
            elif fn == "top_companies_by_units":
                if len(args) == 0: txt, figs = top_companies_by_units("5", None)
                elif len(args) == 1: txt, figs = top_companies_by_units(args[0], None)
                else: txt, figs = top_companies_by_units(args[0], args[1])
            elif fn == "top_drugs_by_units":
                if len(args) == 0: txt, figs = top_drugs_by_units("5", None)
                elif len(args) == 1: txt, figs = top_drugs_by_units(args[0], None)
                else: txt, figs = top_drugs_by_units(args[0], args[1])
            elif fn == "top_drugs_by_value":
                if len(args) == 0: txt, figs = top_drugs_by_value("5", None)
                elif len(args) == 1: txt, figs = top_drugs_by_value(args[0], None)
                else: txt, figs = top_drugs_by_value(args[0], args[1])
            else:
                txt = f"⚠️ Unknown function route: {fn}"

            if isinstance(txt, tuple):
                txt, figs = txt
            self.ask_text.delete(1.0, tk.END); self.ask_text.insert(tk.END, txt)
            if isinstance(figs, list): self.ask_plot.show_figs(figs)
        except Exception as e:
            self.ask_text.delete(1.0, tk.END)
            self.ask_text.insert(tk.END, f"Router Error: {e}")
            traceback.print_exc()

    # Drug
    def _build_tab_drug(self):
        self.drug_entry, self.drug_btn, self.drug_text, self.drug_plot, self.btn_export_drug = self._make_io_area(
            self.tab_drug, "Active ingredient name (Persian or English):"
        )
        self.drug_btn.configure(command=self._run_drug)
        self.btn_export_drug.configure(command=lambda: self._export_pdf("drug"))

    def _run_drug(self):
        name = self.drug_entry.get().strip()
        if not name: messagebox.showinfo("Hint","Enter an ingredient name."); return
        try:
            text, figs = summarize_drug(name)
            self.drug_text.delete(1.0, tk.END); self.drug_text.insert(tk.END, text)
            self.drug_plot.show_figs(figs)
            self.last_drug_text, self.last_drug_figs = text, figs
            self.btn_export_drug.configure(state="normal")
        except Exception as e:
            self.drug_text.delete(1.0, tk.END); self.drug_text.insert(tk.END, f"Error: {e}")
            traceback.print_exc()

    # Company
    def _build_tab_company(self):
        self.comp_entry, self.comp_btn, self.comp_text, self.comp_plot, self.btn_export_company = self._make_io_area(
            self.tab_company, "Company (Licensee) name (Persian or English):"
        )
        self.comp_btn.configure(command=self._run_company)
        self.btn_export_company.configure(command=lambda: self._export_pdf("company"))

    def _run_company(self):
        name = self.comp_entry.get().strip()
        if not name: messagebox.showinfo("Hint","Enter a company name."); return
        try:
            text, figs = analyze_company(name)
            self.comp_text.delete(1.0, tk.END); self.comp_text.insert(tk.END, text)
            self.comp_plot.show_figs(figs)
            self.last_company_text, self.last_company_figs = text, figs
            self.btn_export_company.configure(state="normal")
        except Exception as e:
            self.comp_text.delete(1.0, tk.END); self.comp_text.insert(tk.END, f"Error: {e}")
            traceback.print_exc()

    # Compare drugs
    def _build_tab_cmp_drugs(self):
        top = ttk.Frame(self.tab_cmp_drugs)
        top.pack(side=tk.TOP, fill=tk.X, padx=8, pady=6)

        # Drug 1 box
        box1 = ttk.Frame(top)
        box1.pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Label(box1, text="Drug A:").pack(anchor="w")
        self.cmpd_entry1 = ttk.Entry(box1, width=30)
        self.cmpd_entry1.pack(fill=tk.X, padx=4, pady=3)

        # Drug 2 box
        box2 = ttk.Frame(top)
        box2.pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Label(box2, text="Drug B:").pack(anchor="w")
        self.cmpd_entry2 = ttk.Entry(box2, width=30)
        self.cmpd_entry2.pack(fill=tk.X, padx=4, pady=3)

        # Buttons
        run_btn = ttk.Button(top, text="Run", command=self._run_cmp_drugs)
        run_btn.pack(side=tk.LEFT, padx=6)

        self.btn_export_cmpd = ttk.Button(top, text="Save PDF", state="disabled",
                                    command=lambda: self._export_pdf("cmp_drugs"))
        self.btn_export_cmpd.pack(side=tk.LEFT, padx=6)

    # OUTPUT AREA
        mid = ttk.Frame(self.tab_cmp_drugs)
        mid.pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        self.cmpd_text = scrolledtext.ScrolledText(mid, height=18)
        self.cmpd_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        right = ttk.Frame(mid)
        right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.cmpd_plot = PlotHost(right)

    def _run_cmp_drugs(self):
        d1 = self.cmpd_entry1.get().strip()
        d2 = self.cmpd_entry2.get().strip()

        if not d1 or not d2:
            messagebox.showinfo("Hint", "Enter both Drug A and Drug B names.")
            return

        try:
            text, figs = compare_drugs(d1, d2)
        
            # Fix: ایمن delete/insert با RTL + chunking برای long text
            self.cmpd_text.config(state=tk.NORMAL)
            self.cmpd_text.delete("1.0", tk.END)
        
            safe_text = fa_display(text or "No data")
            for line in safe_text.splitlines(keepends=True)[:1000]:  # limit lines
                self.cmpd_text.insert(tk.END, line)
        
            self.cmpd_text.see(tk.END)
            self.cmpd_text.config(state=tk.DISABLED)  # read-only optional
        
            self.cmpd_plot.show_figs(figs)
            self.last_cmpd_text, self.last_cmpd_figs = text, figs
            self.btn_export_cmpd.configure(state="normal")
        except Exception as e:
            self.cmpd_text.config(state=tk.NORMAL)
            self.cmpd_text.delete("1.0", tk.END)
            self.cmpd_text.insert("1.0", f"Error:\n{str(e)[:1000]}")
            self.cmpd_text.see(tk.END)
            traceback.print_exc()

    # Compare companies
    def _build_tab_cmp_companies(self):
        top = ttk.Frame(self.tab_cmp_companies); top.pack(side=tk.TOP, fill=tk.X, padx=8, pady=6)
        ttk.Label(top, text="Company A:").pack(side=tk.LEFT, padx=4)
        self.cmpc_entry1 = ttk.Entry(top, width=30); self.cmpc_entry1.pack(side=tk.LEFT, padx=(0,10))
        ttk.Label(top, text="Company B:").pack(side=tk.LEFT, padx=4)
        self.cmpc_entry2 = ttk.Entry(top, width=30); self.cmpc_entry2.pack(side=tk.LEFT, padx=(0,10))
        self.cmpc_btn = ttk.Button(top, text="Run", command=self._run_cmp_companies); self.cmpc_btn.pack(side=tk.LEFT, padx=6)
        self.btn_export_cmpc = ttk.Button(top, text="Save as PDF", state="disabled", command=lambda: self._export_pdf("cmp_companies")); self.btn_export_cmpc.pack(side=tk.RIGHT, padx=6)

        mid = ttk.Frame(self.tab_cmp_companies); mid.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        self.cmpc_text = scrolledtext.ScrolledText(mid, height=18)
        self.cmpc_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(8,4), pady=(0,8))
        right = ttk.Frame(mid); right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(4,8), pady=(0,8))
        self.cmpc_plot = PlotHost(right)

    def _run_cmp_companies(self):
        c1 = self.cmpc_entry1.get().strip()
        c2 = self.cmpc_entry2.get().strip()
        if not c1 or not c2:
            messagebox.showinfo("Hint","Enter both company names."); return
        try:
            text, figs = compare_companies(c1, c2)
            self.cmpc_text.delete(1.0, tk.END); self.cmpc_text.insert(tk.END, text)
            self.cmpc_plot.show_figs(figs)
            self.last_cmpc_text, self.last_cmpc_figs = text, figs
            self.btn_export_cmpc.configure(state="normal")
        except Exception as e:
            self.cmpc_text.delete(1.0, tk.END); self.cmpc_text.insert(tk.END, f"Error: {e}")
            traceback.print_exc()

    # Disease
    def _build_tab_disease(self):
        top = ttk.Frame(self.tab_disease)
        top.pack(side=tk.TOP, fill=tk.X, padx=8, pady=6)

        ttk.Label(top, text="Disease (Persian or English):").pack(side=tk.LEFT, padx=4)
        self.dis_entry = ttk.Entry(top, width=40)
        self.dis_entry.pack(side=tk.LEFT, padx=(0, 10))

        self.dis_btn = ttk.Button(top, text="Run", command=self._run_disease)
        self.dis_btn.pack(side=tk.LEFT, padx=6)

        # دکمه Save PDF برای Disease
        self.btn_export_disease = ttk.Button(
            top,
            text="Save PDF",
            state="disabled",
            command=lambda: self._export_pdf("disease")
        )
        self.btn_export_disease.pack(side=tk.LEFT, padx=6)

        mid = ttk.Frame(self.tab_disease)
        mid.pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        self.dis_text = scrolledtext.ScrolledText(mid, height=18)
        self.dis_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        right = ttk.Frame(mid)
        right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    # اگر برای Disease هم نمودار می‌سازی، می‌توانی PlotHost بگذاری، در غیر این صورت لازم نیست

    def _run_disease(self):
        name = self.dis_entry.get().strip()
        if not name:
            messagebox.showinfo("Hint", "Enter a disease name.")
            return
        try:
            text = disease_analysis(name)  # در کد تو فقط متن برمی‌گرداند
            # RTL-safe insert
            self.dis_text.config(state=tk.NORMAL)
            self.dis_text.delete("1.0", tk.END)
            for line in (text or "").splitlines(keepends=True):
                self.dis_text.insert(tk.END, fa_display(line))
            self.dis_text.see(tk.END)
            self.dis_text.config(state=tk.DISABLED)

            self.last_disease_text = text
            self.last_disease_figs = []  # اگر بعداً شکل اضافه کردی، اینجا ست کن
            self.btn_export_disease.configure(state="normal")
        except Exception as e:
            self.dis_text.config(state=tk.NORMAL)
            self.dis_text.delete("1.0", tk.END)
            self.dis_text.insert("1.0", f"Error:\n{str(e)[:1000]}")
            self.dis_text.see(tk.END)
            traceback.print_exc()


    # Settings
    def _build_tab_settings(self):
        frm = ttk.Frame(self.tab_settings); frm.pack(fill=tk.BOTH, expand=True, padx=12, pady=12)
        ttk.Label(frm, text="OPENAI_API_KEY:").grid(row=0, column=0, sticky="w", padx=4, pady=4)
        self.ent_key = ttk.Entry(frm, width=60); self.ent_key.grid(row=0, column=1, sticky="w", padx=4, pady=4)
        self.ent_key.insert(0, OPENAI_API_KEY or "")
        ttk.Label(frm, text="OPENAI_MODEL:").grid(row=1, column=0, sticky="w", padx=4, pady=4)
        self.ent_model = ttk.Entry(frm, width=30); self.ent_model.grid(row=1, column=1, sticky="w", padx=4, pady=4)
        self.ent_model.insert(0, OPENAI_MODEL)
        self.chk_ai = tk.BooleanVar(value=AI_CALLS_ENABLED)
        ttk.Checkbutton(frm, text="Enable AI calls", variable=self.chk_ai).grid(row=2, column=1, sticky="w", padx=4, pady=4)

        ttk.Button(frm, text="Save Config", command=self._save_settings).grid(row=3, column=1, sticky="w", padx=4, pady=8)

    def _save_settings(self):
        cfg = load_config()
        cfg["OPENAI_API_KEY"] = self.ent_key.get().strip()
        cfg["OPENAI_MODEL"] = self.ent_model.get().strip() or "gpt-5"
        cfg["AI_CALLS_ENABLED"] = bool(self.chk_ai.get())
        try:
            save_config(cfg)
            messagebox.showinfo("Saved", f"Config saved to: {CONFIG_PATH}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save config: {e}")

    # PDF Export dispatcher
    def _export_pdf(self, kind: str):
        # 1) انتخاب عنوان، متن و شکل‌ها بر اساس kind
        title = ""
        text = ""
        figs = []

        if kind == "drug":
            title = f"Drug Analysis — {getattr(self, 'last_drug_name', '').strip() or 'Drug'}"
            text = getattr(self, "last_drug_text", "")
            figs = getattr(self, "last_drug_figs", [])
        elif kind == "company":
            title = f"Company Analysis — {getattr(self, 'last_company_name', '').strip() or 'Company'}"
            text = getattr(self, "last_company_text", "")
            figs = getattr(self, "last_company_figs", [])
        elif kind == "cmp_drugs":
            title = "Drug Head-to-Head"
            text = getattr(self, "last_cmpd_text", "")
            figs = getattr(self, "last_cmpd_figs", [])
        elif kind == "cmp_companies":
            title = "Company Head-to-Head"
            text = getattr(self, "last_cmpc_text", "")
            figs = getattr(self, "last_cmpc_figs", [])
        elif kind == "disease":
        # بیماری
            dis_name = self.dis_entry.get().strip() if hasattr(self, "dis_entry") else ""
            title = f"Disease Analysis — {dis_name or 'Disease'}"
            text = getattr(self, "last_disease_text", "")
            figs = getattr(self, "last_disease_figs", [])
        else:
            messagebox.showerror("Export", f"Unknown export kind: {kind}")
            return

        if not text:
            messagebox.showinfo("Export", "Nothing to export.")
            return

    # 2) انتخاب مسیر ذخیره (فقط یک‌بار این‌جا fpath تعریف می‌شود)
        fpath = filedialog.asksaveasfilename(
            defaultextension=".pdf",
            filetypes=[("PDF files", "*.pdf")],
            title="Save report as PDF"
        )
        if not fpath:
            return

    # 3) ساخت PDF
        ok, err = export_report_to_pdf(fpath, title, text, figs)
        if ok:
            messagebox.showinfo("Export", "PDF saved successfully.")
        else:
            messagebox.showerror("Export error", err or "Unknown error.")

if __name__ == "__main__":
    try:
        app = App()
        app.mainloop()
    except Exception as e:
        print("App error:", e)
