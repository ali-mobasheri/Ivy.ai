import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = 'django-insecure-ivy-ai-secret-key-change-in-production'
DEBUG = True
ALLOWED_HOSTS = ['*']

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'rest_framework',
    'analytics',
]

# ivy.ai Media & Static
MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'
STATIC_URL = '/static/'
STATICFILES_DIRS = [BASE_DIR / 'static']

# ivy.ai AI Configs (از paste.txt)
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "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")
GOOGLE_CSE_API_KEY = os.getenv("GOOGLE_CSE_API_KEY", "AIzaSyCdQORXQYS_hNLLykNUExScVKBZwl3z3Us")
GOOGLE_CSE_CX = os.getenv("GOOGLE_CSE_CX", "d5086ce7fd7e64c8f")

AI_CALLS_ENABLED = True
AI_CACHE_TTL_SEC = 600
AI_MIN_INTERVAL_SEC = 5
AI_MAX_PER_MINUTE = 6

# باقی settings...
